{{- /* The postgresql ConfigMap's whole document, as a named template so statefulset.yaml can
       checksum it without including postgresql-configmap.yaml -- a template-file include
       makes every unit-test suite that renders statefulset.yaml list the ConfigMap too, and
       the ConfigMap renders on every install since the connection reserves. */ -}}
{{- define "pg.postgresqlConfigMap" -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ include "pg.fullname" . }}-postgresql-config
  labels:
    {{- include "pg.labels" . | nindent 4 }}
    app.kubernetes.io/component: postgresql
  {{- with (include "pg.annotations" .) }}
  annotations:
    {{- . | nindent 4 }}
  {{- end }}
data:
{{- if not .Values.ha.enabled }}
  # Standalone first boot (mounted at /docker-entrypoint-initdb.d by statefulset.yaml): the
  # official image sources this after initdb and BEFORE the first real server start, so conf.d
  # -- reserved-connections.conf among it -- is loaded by that start. Postmaster-level settings
  # such as reserved_connections cannot be applied by a later reload, and on a fresh volume the
  # setup-config init container has no postgresql.conf to edit yet. Every later start is
  # setup-config's. include_dir only reads *.conf, so this file is inert in conf.d itself.
  include-confd.sh: |
    if ! grep -q "^include_dir = '/etc/postgresql/conf.d'" "$PGDATA/postgresql.conf"; then
      echo "include_dir = '/etc/postgresql/conf.d'" >> "$PGDATA/postgresql.conf"
    fi
{{- end }}
{{- /* When the chart owns shared_preload_libraries (pgaudit must be preserved -- the
       repmgr prepend went with the mechanism in #294, and #293's
       pg.validateNativePreloadRepmgr now REFUSES any render that asks for it), the merged
       value is emitted from an authoritative file below that sorts
       after custom.conf under conf.d's include_dir; emitting it here too would be a dead
       duplicate that file overrides, so skip it. Matched case-insensitively -- PostgreSQL
       GUC names are case-insensitive, and the merge helper reads the key the same way, so
       both must agree or a non-canonically cased key would be emitted here yet dropped
       from the merged preload list. Keys are collected first so custom.conf is omitted
       entirely (rather than emitted empty) when the preload key was its only entry. */}}
{{- $ownsPreload := eq (include "pg.chartOwnsSharedPreloadLibraries" .) "true" }}
{{- $customKeys := list }}
{{- range $key, $value := (.Values.postgresql.configuration | default dict) }}
{{- if not (and $ownsPreload (eq (lower ($key | toString)) "shared_preload_libraries")) }}
{{- $customKeys = append $customKeys $key }}
{{- end }}
{{- end }}
  # Connection reserves (see pg.superuserReservedConnections). Sorts after custom.conf,
  # and pg.validateConnectionReserves refuses these keys there, so this is their only
  # source.
  reserved-connections.conf: |
    superuser_reserved_connections = {{ include "pg.superuserReservedConnections" . }}
    reserved_connections = {{ include "pg.reservedConnections" . }}
{{- if $customKeys }}
  custom.conf: |
    {{- range $key := $customKeys }}
    {{ $key }} = '{{ index $.Values.postgresql.configuration $key | toString | replace "'" "''" }}'
    {{- end }}
{{- end }}
{{- if .Values.pgbackrest.enabled }}
  # Required for pgbackrest WAL archiving. archive_mode is a postmaster
  # parameter so it only takes effect after a postgres restart, which the
  # configmap checksum annotation on the StatefulSet triggers.
  #
  # max_wal_senders is deliberately NOT set here: it used to be hardcoded to the same
  # value images/pg-ha/entrypoint.sh already sets at initdb, which meant this file
  # clobbered any larger postgresql.configuration.max_wal_senders for no reason
  # (nothing else needs it re-asserted). Removed; the value now simply flows from
  # postgresql.configuration (via custom.conf) or the initdb default, uncontested.
  #
  # wal_level is intentionally NOT set here (#308) -- it must work whether or not
  # pgBackRest is even enabled, so it has its own render block below, independent of
  # this one.
  pgbackrest-archive.conf: |
    archive_mode = on
    archive_command = 'pgbackrest --stanza={{ .Values.pgbackrest.stanza | toString | replace "'" "''" }} archive-push %p'
{{- end }}
{{- if ne (.Values.postgresql.walLevel | default "replica") "replica" }}
  # wal_level (#308): sourced from postgresql.walLevel, the one authoritative source
  # (the pg.validateWalLevel guard rejects setting wal_level in
  # postgresql.configuration directly). Deliberately independent of
  # pgbackrest.enabled -- a logical subscriber must work whether or not backups are
  # configured; wal_level and archive_mode are unrelated concerns that a prior
  # revision of this file wrongly coupled. Only rendered when non-default, so the
  # default render (and this ConfigMap's existence at all, for installs that touch
  # nothing else here) stays byte-stable -- images/pg-ha/entrypoint.sh's own
  # initdb-time default already sets this GUC to the same default, so there is
  # nothing to add when the value is left unchanged. This file sorts after custom.conf and
  # pgbackrest-archive.conf under conf.d's include_dir either way, so it would win
  # even if it were unconditional.
  wal-level.conf: |
    wal_level = {{ .Values.postgresql.walLevel }}
{{- end }}
{{- if .Values.postgresql.tls.enabled }}
  # Server TLS (#110). The cert Secret is mounted at /etc/postgresql/tls; ssl_ca_file
  # is set only under mutual TLS (it verifies CLIENT certs). ssl is SIGHUP-reloadable;
  # the configmap checksum annotation rolls the pod when this changes.
  tls.conf: |
    ssl = on
    ssl_cert_file = '/etc/postgresql/tls/tls.crt'
    ssl_key_file = '/etc/postgresql/tls/tls.key'
{{- if .Values.postgresql.tls.clientCertAuth }}
    ssl_ca_file = '/etc/postgresql/tls/ca.crt'
{{- end }}
{{- end }}
{{- if .Values.postgresql.audit.enabled }}
  # pgaudit audit logging (#219). shared_preload_libraries is a postmaster parameter,
  # so it takes effect only after a restart -- toggling audit.enabled changes this
  # ConfigMap's checksum, which the StatefulSet's checksum/postgresql-config annotation
  # turns into a controlled rolling restart. This file sorts after custom.conf under
  # conf.d's include_dir, so its shared_preload_libraries is authoritative; the helper
  # keeps any operator-declared libraries and adds pgaudit. It adds nothing else: the
  # `repmgr` prepend was deleted in #294 with the mechanism, and asking for repmgr here is
  # now a hard render failure (pg.validateNativePreloadRepmgr) because this image ships no
  # repmgr.so -- a preload of it would make every pod unstartable.
  pgaudit.conf: |
    shared_preload_libraries = '{{ include "pg.sharedPreloadLibraries" . }}'
    pgaudit.log = '{{ .Values.postgresql.audit.log | toString | replace "'" "''" }}'
    pgaudit.log_catalog = {{ ternary "on" "off" .Values.postgresql.audit.logCatalog }}
    pgaudit.log_parameter = {{ ternary "on" "off" .Values.postgresql.audit.logParameter }}
    pgaudit.log_relation = {{ ternary "on" "off" .Values.postgresql.audit.logRelation }}
{{- if .Values.postgresql.audit.role }}
    pgaudit.role = '{{ .Values.postgresql.audit.role | toString | replace "'" "''" }}'
{{- end }}
{{- end }}
{{- if and (eq (include "pg.agentMode" .) "true") .Values.ha.agent.syncReplicationSlots }}
  # Logical failover slot sync (#308), PostgreSQL 17+. sync_replication_slots is a plain
  # boolean, not topology-dependent (unlike synchronized_standby_slots below, which the
  # agent reconciles per-tick on the primary via ALTER SYSTEM as the standby set changes),
  # so it is safe to set unconditionally here rather than needing agent involvement: it
  # enables the slot-sync worker on a standby, and is a documented no-op on a primary
  # (there is nothing there for it to sync).
  sync-replication-slots.conf: |
    sync_replication_slots = on
{{- end }}
{{- end -}}
