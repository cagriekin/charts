# pg chart changelog

## 2.0.0 - 2026-09-02

The failover agent is now the only HA mechanism. repmgrd, the repmgr CLI mechanism and their
sidecars are gone; the agent drives PostgreSQL directly, and a live 1.x cluster migrates in place.

### Changed (breaking)

- **`native` is the only replication mechanism, and the default** (#294, #288, #289). The agent
  drives PostgreSQL directly -- `pg_ctl promote`, `pg_basebackup`, `pg_rewind`, and
  `primary_conninfo` + `standby.signal` -- reads topology from `pg_stat_replication` instead of
  `repmgr.nodes`, and owns physical replication slot lifecycle (`pg_ha_slot_<ordinal>`, created on
  the upstream before the clone, orphans reclaimed, an active slot never dropped). A native cluster
  has no repmgr extension and no `repmgr.nodes`; the `repmgr` role and database remain (the agent
  authenticates as that role) and renaming them is deferred. The Lease is still the sole authority
  for who is primary -- election, fencing and Service routing are unchanged.
- **`repmgr.failoverMode: repmgrd` and the repmgrd + service-updater sidecars are removed** (#286).
  The lease-based agent has been the default since 1.0.0. Removed with them: the `repmgrd` and
  `service-updater` containers, kubectl and `shareProcessNamespace` from the pod, the `pods delete`
  and pgpool `deployments` RBAC grants, the `PrimaryChanged` core Events (failover history is now
  the agent audit log and the `pg_ha_agent_*` metrics), and the postgresql->pgpool:9999 egress
  rule. `podManagementPolicy` moves `OrderedReady` -> `Parallel`, which is immutable -- repmgrd
  users recreate the StatefulSet once; see Migrating.
- **The `repmgr:` values block is now `ha:`** (#291). Only the block name changed; every `repmgr.*`
  key still works for the whole 2.0.0 line (merged over `ha:` key by key, with a deprecation notice
  on upgrade) and is removed in the next major. `repmgr.*` wins over `ha.*` from any source
  including `--set`, so MOVE a key rather than duplicate it. `ha.username`, `ha.database` and the
  `repmgr-password` Secret key keep the word -- they name live PostgreSQL objects, not the tool.
- **The HA image is versioned with the chart** (#290). Tags are now
  `cagriekin/pg-ha:<chart-version>-pg<major>` (e.g. `2.0.0-pg18`, `2.0.0-pg17`), published from git
  tag `pg-ha-<version>`, replacing `cagriekin/repmgr:trixie-<repmgr>-<n>`. The old `cagriekin/repmgr`
  tags stay published and frozen, so existing pins keep resolving. A pin must name its major
  (`ha.image.majorVersion` cross-checks it at render time); there is no default-major alias. The
  helper `pg.repmgrImage` is renamed `pg.haImage` to match.
- **An unquoted numeric `image.tag` / `image.digest` is refused at render time** (#298). YAML parses
  `tag: 18` to a float, so `18`/`18.0` and `2.10`/`2.1` arrive indistinguishable and a chart could
  deploy an image the values file never named. Quote every tag (`tag: "18"`); on the command line
  use `--set-string`. Affects `pg`, `pgvector` and `etcd`.

### Removed (breaking)

Each removed key is rejected at render time with a message naming the fix, so a stale values file
fails the upgrade instead of silently deploying something else.

- **`ha.splitBrainDetection`** (and the `repmgr.splitBrainDetection` alias). Its `log`/`fence`
  choice selected between behaviours that became identical once repmgrd was removed; the agent
  always demotes when it is read-write without holding the lease. The protection is unchanged.
- **`repmgr.failoverMode`, `repmgr.serviceUpdater.*`, `repmgr.monitoringHistoryDays` and
  `pgpool.autoFailback`** -- each tied to repmgrd or the service-updater.

### Added

- **In-place migration of a live 1.x repmgr cluster to native** (#292). `helm upgrade` migrates
  without a re-clone -- timeline and system identifier preserved, no switchover. The agent strips
  `shared_preload_libraries = 'repmgr'` from PGDATA before the postmaster starts (#293; the 2.0.0
  image has no `repmgr.so`), clears repmgr's `primary_conninfo`/`primary_slot_name` from
  `postgresql.auto.conf`, and drops a legacy `repmgr_slot_*` only once its standby is on the
  replacement slot. The repmgr database, role and extension are left in place -- dropping them ends
  rollback, so it is an opt-in operator step. Full runbook in `pg/README.md`, verified end to end on
  a real cluster. `helm rollback` on any agent-mode release needs `--force-conflicts` (the agent
  owns `Service.spec.selector`).
- **Slot-retention and replica alerting.** New gauges (`pg_ha_agent_replication_slots*`,
  `pg_ha_agent_replicas_*`) and `PrometheusRule` alerts turn a silent WAL-pinning slot, an
  invalidated slot, a tampered primary marker and a missing streaming standby into pages -- several
  were previously exported but never thresholded. Slot observation runs under the repmgr mechanism
  too; ownership is native-only.

### Security

Hardening from a security review of the 2.0.0 line (#298). The highest-impact items require an
attacker who already holds the agent's ServiceAccount token (a compromised pg pod).

- A forged peer `RestoredAt` annotation can no longer promote a stale node (must be RFC3339, no more
  than an hour ahead of now).
- The Lease `holderIdentity` and every follow/clone/rejoin target must match this cluster's
  `<name>-<ordinal>` pod grammar, closing a libpq-keyword injection into the replication conninfo.
- Bootstrap passwords go in on stdin, not a `psql -c` command line; child processes (psql,
  pg_basebackup, pg_rewind, pgbackrest) no longer inherit `*PASSWORD` env.
- Role names, `PGBACKREST_STANZA` and `postgresql.pgHba` entries are validated before they reach
  pg_hba.conf, the archive_command GUC or the postStart hook.
- Security-relevant keys (`ha.agent.podCidr`, the control-API `allowedClientCNs`, the restore
  admission policy) can no longer be set via the deprecated `repmgr.*` alias.
- Image supply chain: the PGDG apt fetch is pinned to HTTPS, the publish-workflow actions are pinned
  to commit SHAs, and the etcd RBAC-bootstrap Job drops its ServiceAccount token.

### Migrating from 1.x

**On the default (agent):** delete `repmgr.failoverMode: agent` if you set it explicitly, then
`helm upgrade` normally. Your StatefulSet is already `Parallel`; there is no recreate.

**Pinned `repmgr.failoverMode: repmgrd`:** `podManagementPolicy` (`OrderedReady` -> `Parallel`) is
immutable, so the StatefulSet must be recreated once (no data loss -- pods and PVCs are kept):

```bash
# Healthy cluster + a fresh backup first. GitOps: disable auto-sync for these steps.
kubectl delete statefulset <release>-pg -n <ns> --cascade=orphan
# Remove every removed key from your values (see Removed above), then upgrade -- this recreates
# the StatefulSet as Parallel and adopts the orphaned pods:
helm upgrade <release> cagriekin/pg -n <ns>   # + your -f values, minus the removed keys
kubectl get lease <release>-pg-leader -n <ns> -o jsonpath='{.spec.holderIdentity}'
```

Rollback is chart `1.x` with `failoverMode: repmgrd` restored and the same `--cascade=orphan`
recreate. repmgrd users also move to a pod-CIDR + SCRAM `pg_hba.conf` with no implicit
`0.0.0.0/0 md5` catch-all -- add explicit `postgresql.pgHba` rules first if you relied on it.

## 1.17.0 - 2026-08-26

Ships repmgr image `trixie-5.5.0-34`. Two HA-availability fixes, both of which could
leave a cluster with no serving primary and no automatic way back.

### Fixed

- **The etcd DCS no longer produces zombie candidates or phantom leadership (#326, #327).**
  `EtcdDCS.runElection` called `Election.Campaign` unguarded. etcd's `Campaign` puts a
  lease-bound candidate key and then blocks in `waitDeletes()` watching only lower-revision
  keys; session expiry is not one of its exits (documented upstream, unchanged between
  v3.5.12 and the vendored v3.5.31, so there is nothing upstream to adopt).

  Two failures followed. If the lease lapsed mid-campaign, etcd deleted the node's candidate
  key while `Campaign` stayed blocked forever: the node held no lease and no key, was absent
  from the election, and the `Run` loop never re-contended. A standby in that state cannot
  take over, so the cluster silently has **no failover**. And when the leader's key was
  eventually deleted, `waitDeletes` returned nil, so `Campaign` returned "you are leader"
  while the node held nothing — the agent then acted as leader concurrently with the peer
  holding the real lease.

  Observed in the field: a two-node cluster whose primary self-fenced on a transient etcd
  blip, with the standby already a zombie candidate. No peer took over for two hours, and
  the eventual double-leadership drove a rejoin that emptied the standby's data directory.

  The campaign is now bound to the session: it is cancelled when the lease lapses, so the
  `Run` loop starts a fresh iteration, and liveness is re-checked before leadership is
  reported. The lapse path deliberately does not wait for `Campaign` to unwind — its cancel
  path calls `Resign` on the client context, which carries no deadline and defaults to
  `WaitForReady(true)`, so it can block for the whole outage.

  `k8sdcs` is unaffected: client-go `leaderelection` owns renewal and cannot reach this state.

- **An empty data directory on ordinal 0 now clones instead of crash-looping (#325).** The
  init container derived its role from the pod ordinal, so a pod-0 that lost or recreated its
  PVC declared "First boot" and skipped the clone; the entrypoint guard then correctly refused
  to `initdb` next to an active primary, leaving the pod in CrashLoopBackOff with no automatic
  way out. An ordinal > 0 recovered from the identical failure, purely because of its name.
  The role is now decided from the cluster — probe for a primary, then for any live peer —
  and reuses the existing standby clone path.

- **Data carrying `standby.signal` is treated as standby-state whatever the ordinal (#325).**
  Otherwise ordinal 0 fell through to the master block, which `rm -rf`s PGDATA and takes a full
  base backup — on every restart of a healthy pod-0 standby, and unrecoverable if every clone
  attempt failed, since it deletes before it clones.

- **A standby that cannot reach a primary defers instead of failing (#325).** With `set -e`, a
  bare `wait_for_primary` returning 1 exits the init container. Now that ordinal 0 can reach
  that path, hard-failing would deadlock a cold boot: under `OrderedReady` pod-0 is recreated
  alone and blocks pod-1, so it waits ~240s for a primary that cannot exist, exits, and repeats
  while the real primary is never created. Existing data now defers to the entrypoint guard and
  starts in recovery, as the master block did. Only an empty directory still fails.

### Known gaps

- `Leader()` can still name a node that has already gone, and the `observe` loop does not
  restart after a watch disruption. `Election.Observe` never reports a deletion, so clearing
  the cache needs a prefix watch for DELETE events or `el.Leader()` polling. Tracked on #326.
- A repeatedly failing etcd session is not logged and the client is not redialled, so a wedged
  etcd client is invisible. Tracked on #326.

## 1.16.0 - 2026-08-25

### Added

- **`pgbackrest.extraEnv` / `extraVolumes` / `extraVolumeMounts`: point the pgBackRest workloads
  at a non-default apiserver route or repository route (#323).** `postgresql` has had all three
  since #262; none of the pgBackRest workloads had any equivalent, and each carried one
  hardcoded `env:` block.

  That gap has teeth because the **backup CronJob is an apiserver client**: it resolves the
  current primary at fire time by listing EndpointSlices and then drives pgBackRest with
  `kubectl exec`, which is exactly what makes the schedule survive a failover. Where the pod's
  default route to `kubernetes.default.svc` is closed -- a CNI policy denying the
  `kube-apiserver` entity for a tenant namespace, say -- the schedule runs, `kubectl` times out,
  and no backup is ever taken. The agent could already escape this with `KUBECONFIG` and
  `postgresql.extraEnv` (#317); the CronJob could not.

  The second-order damage is worse than the missed backup: that CronJob is the chart's **only**
  caller of `stanza-create`, so the repository is never initialised and `archive_command` fails
  on every WAL segment from the moment the cluster starts -- `archived_count 0,
  failed_count 196` an hour into a database's life, on a cluster where every pod, Service and
  policy reads as correctly configured.

  All three reach **every** container that runs pgBackRest or drives it: the `pgbackrest`
  sidecar and the `pgbackrest-bootstrap` init container in the postgresql pod, the `full`/`diff`
  backup CronJobs, the restore Job/CronJob, and the validation CronJob. The sidecar is included
  deliberately -- `stanza-create` and `backup` actually execute there, via `kubectl exec` from
  the CronJob, so a value that reached the CronJob alone would route the `kubectl` call and
  leave the backup itself unchanged. The **postgresql container is excluded**, equally
  deliberately: it has `postgresql.extraEnv` of its own (also where `archive_command`'s
  pgBackRest invocation reads its environment), and a `KUBECONFIG` injected there would
  redirect the entrypoint's stale-primary guard (#170) as a side effect of configuring backups.

  Guarded at render time by `pg.validatePgbackrestPassthrough`, since each of these failures is
  otherwise apply-time or run-time only: setting any of the three while `pgbackrest.enabled` is
  false is **refused** rather than silently ignored; `extraVolumes` names are checked against
  the chart's own volumes in all four pods *and* against `postgresql.extraVolumes` /
  `postgresql.extensions.extraVolumes`, which land in the same postgresql pod volume list; every
  mount must reference a declared volume, must not repeat a `mountPath`, and must not shadow
  PGDATA (at, above or inside), `/etc/pgbackrest/pgbackrest.conf`, `/scripts`, `/work`, `/tmp`
  or `/var/run/postgresql`; and `extraEnv` may not reuse a chart-set name -- reserved as the
  union over all five containers and unconditionally, so a passthrough that works today cannot
  start shadowing a chart value after a later upgrade enables `repoEncryption` or switches
  `s3.keyType`.

  Two consequences documented in the README rather than left to be discovered.
  `extraVolumes` is pod-level on the **postgresql** pod as well (that is where the sidecar and
  the bootstrap init container live), so a ConfigMap or Secret that does not exist yet holds
  the database pods in `ContainerCreating` on the next roll, not just the backups. And with
  `repmgr.agent.control.restore` enabled, the #279 ValidatingAdmissionPolicy that bounds the
  agent's `create jobs` grant pins the restore Job's volume sources and env `valueFrom` names
  -- the chart folds these values into those pins, so the agent-driven restore keeps working,
  but only sources it can bind to a NAME (`emptyDir`, `configMap`, `secret`,
  `persistentVolumeClaim`; `fieldRef`/`secretKeyRef`/`configMapKeyRef` for env) can be pinned.
  Anything else is a render failure on purpose: admitting an unpinned source would reopen the
  door that policy exists to close, and omitting it would surface as `POST /v1/restore` denied
  at admission during an incident. The names reach single-quoted CEL literals, so they go
  through the same injection guard as every other interpolated value.

  `extraVolumeMounts` paths are normalized before those comparisons: a relative destination is
  refused (the runtime rejects it, so the pod would stay in `CreateContainerError` with nothing
  in the manifest to explain it), and `//var/lib/postgresql/data` or
  `/tmp/../var/lib/postgresql/data` are refused rather than walking around a prefix test onto
  the live data directory.

  No render change with the values unset.

## 1.15.0 - 2026-08-23

### Added

- **`postgresql.extensions.env` / `envFrom` / `extraVolumes` / `extraVolumeMounts`: point the
  extension install at your own apt mirror or proxy (#320).** `copy-base-ext` and `copy-ext`
  had no `env`, no `envFrom` and no volume beyond the three `emptyDir`s, so there was no
  supported way to keep the `apt-get` steps off the public internet.

  That matters under a per-namespace default-deny egress policy, where the cost is not the
  repeated work but the HOSTS: every external host the install touches has to sit in the
  platform's baseline allow, for every tenant, permanently. A Supabase-shaped package set
  needs three -- `apt.postgresql.org`, `repo.pigsty.io`, and `deb.debian.org` (the
  general-purpose Debian archive, for one 165 kB `libsodium23` that neither PGDG nor Pigsty
  ships). A single `http_proxy` now replaces all three, since apt honours it and it needs no
  source rewriting; `extraVolumes`/`extraVolumeMounts` cover what env cannot express -- an
  `/etc/apt/apt.conf.d` snippet or a replacement `sources.list`, which `aptSources` cannot
  provide because it only APPENDS source files and never rewrites the base sources the images
  ship.

  All four apply to **both** extension init containers and to **neither** the postgresql
  container: an `http_proxy` in the postmaster's own environment would silently redirect
  anything else that reads it, and an apt configuration mount there is meaningless. They
  render only while `packages` is non-empty (the plain-copy path runs no apt at all), and
  setting any of them with `packages` empty is **rejected at render time** rather than
  silently ignored -- an operator who believes the proxy is in effect when it is not has a
  worse problem than a failed render.

  Two further guards, both for failures that would otherwise surface only on a running pod.
  An `extraVolumes` entry reusing one of the chart's own volume names (`data`, `ext-lib`,
  `postgresql-config`, ...) is refused: volume names are not merged -- the later entry in the
  pod's list wins -- so it would REPLACE the data PVC or the extension tree with a ConfigMap.
  An `extraVolumeMounts` entry is refused if it mounts over `/ext-lib`, `/ext-share` or
  `/ext-extra-lib` (the trees the install step copies into, which the mount would shadow), or
  if it names a volume absent from `extraVolumes` -- the kubelet rejects that pod at apply
  time, so helm has to catch it first.

  This does not take the install off the pod-start path; a chart-built extension image
  (resolve the packages once, mount the result) remains the larger follow-up.

- **`postgresql.extensions.image`: a prebuilt extension image, so the install leaves the
  pod-start path entirely (#320).** The values above only redirect WHERE the per-start install
  fetches from; this removes it. The packages are resolved once at image build time (new build
  recipe in `images/pg-extensions/`) and a third init container, `copy-prebuilt-ext`, does a
  plain `cp` from that image.

  Two consequences matter more than the speed. There is **no egress on the pod-start path at
  all** -- not proxied, absent, so there is nothing to allow per tenant permanently. And there
  is **no root**: the apt path has to REPLACE `postgresql.containerSecurityContext` with
  `runAsUser: 0` because dpkg needs it, and a namespace enforcing the PSA `restricted` profile
  (or any `runAsNonRoot` admission policy) rejects that pod outright -- so this path works
  where the apt path cannot run at all.

  `packages` and `aptSources` are refused alongside `image`. They are not additive: both
  populate the same `ext-lib`/`ext-share` volumes with a no-clobber copy, so which build of an
  extension actually won would be decided by init-container order -- an implementation detail
  of the template -- rather than by anything in the values file, and a version-pinned package
  silently losing to whatever the image happened to contain is not a trade worth allowing. A
  non-PGDG source belongs in the image build instead (`APT_SOURCE_*` build args). `extraLibs`
  DOES still apply, reading from the prebuilt image's filesystem, so the same absolute paths
  work on either path and a working values file moves across with no other edit.

  Either `tag` or `digest` is required, refused at render time otherwise: an untagged
  reference resolves to `:latest`, which for an extension image means the `.so` files can
  change under a pod restart with nothing in the release changing, and an extension built for
  the wrong major does not load at all. `{major}` in `tag` substitutes
  `postgresql.majorVersion`, as in `packages` and `aptLine`.

  `copy-prebuilt-ext` runs LAST of the three extension init containers and copies with `cp -n`
  (no-clobber), for the same reason `copy-ext` does: `copy-base-ext` populated
  `ext-lib`/`ext-share` from the image that actually RUNS the server, and this is an
  independent build that can sit on a different postgres point release -- an unconditional
  copy would overwrite a core lib (e.g. `libpqwalreceiver.so`) with one the running postmaster
  never linked against (#302).

  It **adds** extensions; it does not upgrade one the server image already ships. The copy is
  no-clobber and runs last, so anything `copy-base-ext`/`copy-ext` already placed wins,
  silently. Concretely: the pgvector chart's `postgresql.image` is `pgvector/pgvector`, which
  ships `vector.so`, so a prebuilt image carrying a NEWER pgvector is a no-op -- change the
  server image for that instead. There is no safe alternative: clobbering the `.so` files would
  overwrite a core lib with a build the running postmaster never linked against (#302), and
  clobbering only the control/SQL files would leave the SQL definitions and the `.so` at
  different versions.

  The image build fails rather than producing a quietly useless artifact when `PACKAGES` is
  empty, the `APT_SOURCE_*` triple is partially set, `APT_SOURCE_LINE` carries no `signed-by=`,
  or the install leaves `/usr/share/postgresql/<major>/extension` empty -- that last one
  catching the mistake otherwise invisible until `CREATE EXTENSION` (a package name that
  exists but installs nothing for this major). CI builds it for both supported majors and runs
  the chart's own copy command verbatim against the result, so drift between the Dockerfile
  and `pg.extensionPrebuiltCopyCommand` cannot go unnoticed.

- **A `pgdg` entry in `postgresql.extensions.aptSources` is now refused at render time
  (#320).** It was always fatal and the failure named nothing useful. Both `postgres:*-trixie`
  and the `cagriekin/repmgr` image already configure `apt.postgresql.org` under their OWN
  keyring paths, and the chart derives its keyring path from the entry `name`
  (`pgchart-<name>-keyring.gpg`) with no override -- so apt sees two entries for the same repo
  with different `Signed-By` values and rejects the ENTIRE source list
  (`E: Conflicting values set for option Signed-By regarding source
  http://apt.postgresql.org/pub/repos/apt/ trixie-pgdg`), failing the install before it
  starts. Omitting the entry is correct: PGDG packages in `packages` resolve from the image's
  own configuration, which is what `packages` already relies on. The guard keys on the HOST,
  not the entry name, so any `aptLine` pointing at `apt.postgresql.org` is caught regardless
  of what it was called.

### Fixed

- **A digest-only image pin rendered an unparseable reference.** `pg.image` built the
  reference with an unconditional `printf "%s:%s"`, so a block with a `digest` and no `tag`
  produced `repo:@sha256:...` -- which containerd rejects (`InvalidImageName`), so the
  container never starts. That made the digest pin, which this chart recommends for
  production, the broken configuration. It now renders `repo@digest`.

**Migrating from 1.14.1:** for almost everyone, nothing to do -- the four override values
default to `[]`, `extensions.image.repository` defaults to `""`, and the default render is
byte-identical. Two changes can fail an upgrade that previously succeeded, both of them
turning a runtime failure into a render-time one:

- **Every image block now requires a tag or a digest, and a non-empty repository.**
  `pg.image` is shared by every image in the chart (postgresql, repmgr, pgpool and its
  exporter, busybox, the metrics exporter, mc, the pgbackrest CronJob), so a values file that
  CLEARS a tag without setting a digest -- `postgresql.image.tag: ""`, `pgpool.image.tag: ""`
  -- now fails at `helm upgrade`. It previously rendered `repo:`, which containerd rejected at
  pod start anyway; the difference is that the failure now names the value instead of showing
  up as `InvalidImageName` on a pod. Set a tag or a digest.
- **A `pgdg` entry in `aptSources` is rejected.** A values file with one now fails at render
  time instead of inside `apt-get update` on every pod start, so a release that was already
  broken this way surfaces at `helm upgrade`.

## 1.14.1 - 2026-08-22

### Changed

- **`repmgr.image.tag` -> `trixie-5.5.0-33` (#317).** The agent now honours `KUBECONFIG`,
  so its apiserver traffic can be routed through an in-cluster proxy. Chart-only change is
  the pinned tag; the behaviour ships in the image.

  Why it exists: the agent reads its primary marker and publishes gossip through the
  apiserver, so on a cluster whose egress policy denies pod traffic to the apiserver **no
  leader is elected and the cluster never gets a serving primary** -- while every pod,
  Service and policy looks correctly configured. Such a policy is not always fixable from
  the policy side: on Cilium deny wins within a tier (no allow rule re-opens the apiserver
  for one namespace) and reserved identities are compound (`reserved:host` and
  `reserved:kube-apiserver` sit on the same identity), so any topology reaching the
  apiserver via a real node IP cannot admit apiserver traffic for one workload without
  admitting node traffic for it. What remains is an in-cluster TCP proxy, which needs a
  different **address** while still verifying the apiserver's own **certificate** -- its
  SANs cover `kubernetes.default.svc` and the apiserver IPs, not the proxy Service.
  Overriding `KUBERNETES_SERVICE_HOST` retargets the dial but leaves no way to set
  `ServerName`, trading a routing failure for a verification failure; `server:` +
  `tls-server-name:` is the pair only a kubeconfig can express.

  **No new value.** Set the variable with `postgresql.extraEnv` and mount the kubeconfig
  with `postgresql.extraVolumes`/`extraVolumeMounts`, both of which already exist. Keep
  `tokenFile`/`certificate-authority` pointed at the ServiceAccount mount so the identity
  stays the pod's ServiceAccount and the chart's RBAC applies unchanged -- only the address
  moves. See the README ["Routing the agent's apiserver traffic"](README.md#routing-the-agents-apiserver-traffic--kubeconfig-317).

  Both apiserver clients take the route: the mutation client (write-Service selector,
  `pg-role` labels, primary marker) **and** the Lease-backed leader election when
  `repmgr.agent.dcs.backend=kubernetes`. Reaching one but not the other would elect a
  leader that cannot publish. `backend=etcd` is unaffected -- leadership never touches the
  apiserver in that mode.

  A `KUBECONFIG` that is set but unreadable, malformed, or contextless is a **startup
  failure naming the file**, not a silent fall back to in-cluster: falling back would
  reproduce the exact hang this escapes, with a kubeconfig mounted and apparently in
  effect. `~/.kube/config` is deliberately **not** consulted, so a stray file cannot
  silently redirect a production cluster. Note `kubectl` is not as strict -- its deferred
  loader does fall back -- so a broken mount degrades the entrypoint's #170 settle guard to
  its fail-open fast path while the agent refuses to boot; mount the kubeconfig from a
  ConfigMap that cannot vanish. The boot log's new `apiserver=` field records which route
  was taken (`kubeconfig <path>` or `in-cluster`), because a denied-egress hang and a
  misrouted kubeconfig otherwise log the same dial timeout.

**Migrating from 1.14.0:** nothing to do. With `KUBECONFIG` unset -- the default, and what
the chart renders -- the agent takes the in-cluster ServiceAccount path exactly as before;
the default render is byte-identical apart from the image tag, so `helm upgrade` rolls the
pods once for the new image and the agent re-establishes leadership with no manual step.

## 1.14.0 - 2026-08-21

### Added

- **`postgresql.extensions.aptSources` (#310).** Adds a non-PGDG apt source (e.g.
  [Pigsty](https://repo.pigsty.io), the only source for `pgsodium`, `supabase_vault`,
  `pg_graphql`, `pg_net`, `supautils`, `wrappers`, `pgjwt`, `pgmq`) inside
  `copy-ext`/`copy-base-ext`'s own throwaway filesystem, before the existing
  `postgresql.extensions.packages` apt-get install -- closing the gap where a
  Pigsty-only package name previously made `copy-base-ext`'s `apt-get install` fail
  outright (the `cagriekin/repmgr` image has no Pigsty source and isn't something a
  chart consumer builds), aborting before its extension-file copy ever ran. Each
  entry's key is dearmored to `/usr/share/keyrings/pgchart-<name>-keyring.gpg` and its
  line written to `/etc/apt/sources.list.d/pgchart-<name>.list` ahead of a second
  `apt-get update` -- the `pgchart-` prefix so an entry can never collide with a source
  the image already owns (the `cagriekin/repmgr` image's own PGDG source); `keyUrl`/
  `aptLine` are restricted to a narrow character allowlist at render time
  (`pg.validateExtensionAptSources`), since both are interpolated into a shell command.
  Requires `packages` to be non-empty. See the README ["Installing packages from a
  non-PGDG apt source"](README.md#installing-packages-from-a-non-pgdg-apt-source-310).
- **`postgresql.extensions.extraLibs` + automatic `LD_LIBRARY_PATH` (#309).** Some
  apt-installed extensions depend on a general-purpose shared library that Debian
  installs to the standard multiarch path (e.g. `libsodium.so.23`, needed by
  `pgsodium`/`supabase_vault`), never under `/usr/lib/postgresql/<major>/lib` where the
  existing extension-file copy reads from -- confirmed live, and true regardless of how
  broad that copy step's glob is. `extraLibs` is an explicit list of exact absolute FILE
  paths (no trailing `/`) to additionally copy into a **new, dedicated** `ext-extra-lib`
  volume -- deliberately kept separate from `ext-lib`, since `ext-lib` is also populated
  by the unvalidated `*.so*` glob copy (either image, #302) and pointing the search path
  there would extend the same ABI-shadowing hazard the denylist below exists to prevent
  to every file that glob happens to sweep in. The `postgresql` container gets
  `LD_LIBRARY_PATH=/usr/lib/postgresql/<major>/extra-lib` automatically whenever
  `extraLibs` is non-empty (not just `extensions.enabled`, so a release that doesn't use
  this feature gets no search-path change and no extra volume at all), since the copied
  file has no `RUNPATH`/`RPATH` and is otherwise never found by the dynamic linker
  (confirmed live end-to-end: fails to load without `LD_LIBRARY_PATH`, loads cleanly
  with it). Deliberately explicit, not an automatic `ldd`-and-copy-everything walk:
  `copy-base-ext`/`copy-ext` can be different image builds, and auto-copying a resolved
  dependency's transitive closure between them risks a runtime ABI mismatch -- every
  library the postmaster itself links is refused at render time (`pg.validateExtraLibs`)
  for exactly that reason: the full `ldd postgres` NEEDED set against the shipped
  `postgres:*-trixie`/`cagriekin/repmgr` images (glibc, OpenSSL, Kerberos, LDAP, ICU,
  zstd/lz4/xz, audit, `libcap`/`libcap-ng`/`libkeyutils`, ...), plus `libpq` (the
  dependency of `libpqwalreceiver.so`, the exact `#302` ABI hazard). An entry must also
  name a real shared library (basename ending `.so`/`.so.<N>`) and not duplicate another
  entry's destination filename -- both would otherwise pass validation and only fail at
  `cp` time, crash-looping the pod. Requires `packages` to be non-empty. See the README
  ["Copying a package's own shared-library
  dependencies"](README.md#copying-a-packages-own-shared-library-dependencies-309).
- **`aptSources[].aptLine` requires `signed-by=` matching its own entry, and rejects
  `trusted=` (review, hardening).** Without `signed-by=/usr/share/keyrings/pgchart-
  <name>-keyring.gpg` naming exactly the keyring the entry's own `keyUrl` is dearmored
  to, apt has no way to know which key to trust for that source -- previously this
  failed only later, at apply time, inside `apt-get update` (`NO_PUBKEY`), instead of at
  render time (CLAUDE.md invariant #4). `trusted=yes` (or any `trusted=` option) is
  rejected outright: it disables apt's signature check entirely, making the
  `curl`/`gpg` verification step above decorative and installing unsigned packages as
  root.
- **`aptSources[].keyUrl` allows `&`; `aptLine` allows `,` and fails on a leftover
  `{`/`}` (review).** `&` in `keyUrl` is needed for a standard keyserver lookup URL
  (`?op=get&search=...`) and is inert inside the double-quoted `curl` argument; `,` in
  `aptLine` is needed for the standard multi-arch option syntax (`[arch=amd64,arm64]`)
  and is inert inside the double-quoted `echo`. A `{`/`}` surviving `{major}`
  substitution in `aptLine` now fails the render instead of silently writing a
  literal, nonsensical placeholder (e.g. a typo'd `{MAJOR}`) into `sources.list.d` that
  would otherwise only fail later, at apply time, inside `apt-get update`.
- **`aptSources`' `curl` is pinned to `https` (review, hardening).** `--proto '=https'
  --proto-redir '=https'` on the key download, so a same-origin `https` -> `http`
  redirect can no longer fetch the key in plaintext. `keyUrl`'s own allowlist already
  forced the URL's own scheme to `https://`, but did not prevent a redirect.
- **`LD_LIBRARY_PATH` is now a chart-reserved `postgresql.extraEnv` name.** Consistent
  with every other chart-set env var (`pg.validateExtraPassthrough` reserves these
  unconditionally, even for a currently-disabled feature, so a passthrough that works
  today can't start silently shadowing a chart value after a later upgrade enables it).
  A `postgresql.extraEnv` entry named `LD_LIBRARY_PATH` now fails the render regardless
  of `extensions.extraLibs`.

### Fixed

- **`copy-ext`/`copy-base-ext`'s extension-file copy glob (`*.so`) missed versioned
  shared libraries a package places directly alongside its own extension modules
  (#309).** The glob is now `*.so*`, a strict superset of the old match, so this is a
  safe, unconditional fix rather than a new opt-in. Note this covers only libraries
  co-located under `/usr/lib/postgresql/<major>/lib` itself -- it does **not** reach a
  dependency Debian installs elsewhere (the motivating `libsodium.so.23` case); that
  needs `postgresql.extensions.extraLibs`, above.

## 1.13.1 - 2026-08-21

### Fixed

- **`repmgr.image.tag` default (`trixie-5.5.0-31`) predated the #311 agent changes
  (#314).** `trixie-5.5.0-31` was tagged before `dbname` primary_conninfo patching and
  `synchronized_standby_slots` reconciliation (#308/#311) landed, so a fresh 1.13.0
  install with `repmgr.agent.syncReplicationSlots: true` set `wal_level`/
  `sync_replication_slots` correctly via ConfigMap, but ran an agent binary that never
  patched `primary_conninfo` or reconciled `synchronized_standby_slots` -- the feature
  documented in the 1.13.0 release notes silently did nothing on the default image.
  Bumped the default to `trixie-5.5.0-32`, built from current `master` (confirmed via
  `grep -a` on the shipped binary: it now contains `synchronized_standby_slots` and
  `EnsurePrimaryConninfoDBName`/`dbNameReloadPending`). `etcd.rbac.bootstrapImage.tag`
  moves in lockstep, as always. No template or values-schema changes; existing
  `repmgr.image.tag` overrides are unaffected.

## 1.13.0 - 2026-08-21

### Added

- **First-class logical replication support and failover slot sync (#308).** Three
  pieces, needed together for a logical subscriber (`CREATE SUBSCRIPTION`, Debezium,
  etc.) to survive a primary failover:

  - **`postgresql.walLevel`** (enum `replica`|`logical`, default `replica`) is now the
    one authoritative source for `wal_level`, rendered independent of
    `pgbackrest.enabled` (its own render block, not `pgbackrest-archive.conf`) so it
    works whether or not backups are configured. Previously, `pgbackrest-archive.conf`
    hardcoded `wal_level = replica` whenever `pgbackrest.enabled`, silently overriding
    `postgresql.configuration.wal_level` because `include_dir` loads conf.d files in
    filename-sort order and that file sorted last.
  - The agent now patches `dbname` into `primary_conninfo` after every clone, follow,
    and rejoin (and deterministically at every cold start of a standby, not only on a
    repoint) -- repmgr's own clone/follow machinery never included it, which is
    harmless for physical replication but breaks PostgreSQL 17+'s
    `sync_replication_slots` worker (it requires `dbname` to be present). The initial
    `standby clone` (run by the `repmgr-init` init container) now also requests a
    physical replication slot in agent mode, matching the agent's own default, so a
    fresh standby's very first streaming connection is slotted from the start.
  - **`repmgr.agent.syncReplicationSlots`** (default `false`, agent-mode only,
    PostgreSQL 17+, requires `postgresql.walLevel: logical` -- enforced at render time):
    when true, sets `sync_replication_slots = on` and has the primary reconcile
    `synchronized_standby_slots` to its current, live standbys' physical replication
    slots on every tick -- so a logical failover slot
    (`CREATE SUBSCRIPTION ... WITH (failover = true)`) survives a promote instead of
    needing a full resync. The live standby set is derived from repmgr's own node
    registry (excluding genuine scale-down ghosts), not from momentary replication-slot
    activity, so a standby restart or brief network blip does not empty the GUC and
    temporarily strand the logical consumer. `synchronized_standby_slots`/
    `sync_replication_slots` do not exist before PostgreSQL 17, so a render-time guard
    rejects the combination with an older `postgresql.majorVersion` (agent mode only --
    the value is inert, and so not guarded, outside it). Verified live on a 3-node KinD
    cluster through install, promote/failover, and scale-down.

  See README ["Logical Replication"](README.md#logical-replication-308) for the full
  detail. The default render is byte-stable (nothing renders differently unless
  `postgresql.walLevel` or `repmgr.agent.syncReplicationSlots` is touched).

### Changed

- `pgbackrest-archive.conf` no longer hardcodes `max_wal_senders = 10` (#308) --
  redundant with the image's own initdb default, and it was silently clobbering a
  custom `postgresql.configuration.max_wal_senders` whenever pgBackRest was enabled.
- **Compatibility note:** `postgresql.configuration.wal_level` is no longer accepted;
  use `postgresql.walLevel` instead (#308). `wal_level` now has exactly one
  authoritative source. If you were setting `postgresql.configuration.wal_level`
  directly with `pgbackrest.enabled: false` (the only combination where it took
  effect), move the value to `postgresql.walLevel` (enum `replica`|`logical`) -- the
  old key now fails at render time with a guard message naming the fix. Everyone else
  is unaffected.

## 1.12.0 - 2026-08-18

### Added

- **`prometheusExporter.prometheusRule`: alert on stuck WAL archiving and pg_wal disk
  usage (#305).** When `archive_command` gets stuck (pgBackRest repository unreachable
  or full), PostgreSQL correctly refuses to recycle un-archived WAL, and nothing
  previously surfaced that growth before it filled the shared PGDATA/`pg_wal` volume.
  This is an **observability-only** fix -- it does not throttle writes or take any
  automatic corrective action when a threshold is crossed; that remains a separate,
  larger change to the Go failover agent's reconcile loop, deliberately out of scope
  here (see README ["WAL Disk Usage"](README.md#wal-disk-usage-305) for the full
  reasoning).

  `prometheusExporter.prometheusRule.enabled` (default `false`) ships a `PrometheusRule`
  wiring `PGWALArchiveFailing`/`PGWALArchiveStale` (the existing `pg_wal_archive_*`
  metrics from #30, collected since 1.x but never wired to an alert until now) and
  `PGWALSizeHigh` (`pg_wal_size_bytes`, the exporter's own **built-in** `wal` collector --
  see below) to configurable thresholds (`staleArchiveSeconds`, `walSizeBytesThreshold`)
  and `for` durations (`archiveFailingFor`/`archiveStaleFor`/`sizeHighFor`).

  **No new metric was added.** The original version of this change defined a chart-side
  `pg_wal_size` query group to report `pg_wal` disk usage. Live-testing against the
  actual shipped exporter image (`quay.io/prometheuscommunity/postgres-exporter:v0.19.1`)
  before merge caught that its `pg_wal_size_bytes` name collides with a metric the
  exporter's own built-in `wal` collector already emits (enabled by default) under the
  same name but different help text -- Prometheus client libraries reject that as a
  duplicate-metric registration, which fails the **entire** `/metrics` scrape, not just
  the new metric. The chart-defined query was deleted; `PGWALSizeHigh` alerts on the
  exporter's pre-existing `pg_wal_size_bytes` directly, so this ships with no new query
  and no new `pg_monitor` grant dependency.

  **Also from review:** the README/values now call out that `prometheusRule.enabled`
  alone is a no-op without `serviceMonitor.enabled` (or an equivalent scrape) actually
  feeding the exporter's metrics to Prometheus.

## 1.11.0 - 2026-08-17

### Added

- **`postgresql.extensions.packages`: install PGDG/Debian extension packages without a
  custom image (#303).** Generalizes the existing `postgresql.extensions.enabled`
  copy-based mechanism: `copy-ext`/`copy-base-ext` can now `apt-get install` a
  render-time-validated package list (`{major}`-substituted against
  `postgresql.majorVersion`, optionally version-pinned with apt's `=` syntax) into their
  own filesystem before the existing lib/share copy, so an extension the donor image
  never shipped (e.g. `postgresql-<major>-cron`) reaches the server the same way
  `postgresql.extensions.enabled` always has. Mechanically: neither init container mounts
  `ext-lib`/`ext-share` at the real native extension paths — only the main postgresql
  container does — so `apt-get install` writes real files there and the existing
  `cp`/`cp -n` (#302) step sweeps them up unchanged.

  Off by default (`packages: []`; a default render is byte-identical to 1.10.2). When
  set, the two init containers run root-transiently for the apt step only (capabilities
  narrowed, not unrestricted — confined to a throwaway container that persists nothing),
  with their own values-overridable `postgresql.extensions.installResources` rather than
  the shared, lighter `pg.initResources`. A render-time guard rejects any package entry
  containing shell metacharacters (the list is interpolated into an `apt-get install`
  shell command) and rejects `packages` set without `extensions.enabled: true`.

  **Review follow-up:** an unversioned PGDG extension dependency on `postgresql-<major>`
  is normally left alone by apt, but nothing stopped some *other* future package from
  declaring a stricter dependency and pulling in a newer `postgresql-<major>` as a side
  effect — silently swapping the very libs about to be copied for a build from a
  different point release than the postmaster this chart actually starts (the #302
  failure mode, one layer up). `copy-ext`/`copy-base-ext` now detect the already-installed
  `postgresql-<major>` version (`dpkg-query`) and pin it on the same `apt-get install`
  line, so apt either leaves it alone (the normal case, confirmed live) or fails the
  install outright — never a silent swap.

  See README ["Installing extensions without a custom image"](README.md#installing-extensions-without-a-custom-image)
  for a complete `pg_cron` example, why `postgresql.databases[].extensions` (not
  `postStart.additionalCommands`) is the right mechanism for the `CREATE EXTENSION` step
  even against the bootstrap database, the PGDG apt-source assumption for a non-default
  `postgresql.image`, the `networkPolicy.postgresql.extraEgress` this requires, and the
  explicit limitation for extensions with no Debian/PGDG package.

### Fixed

- **`shared_preload_libraries` never actually applied before the post-install hook Jobs
  ran on a fresh install (found while verifying #303's own `pg_cron` recipe).**
  `shared_preload_libraries` is a postmaster-restart-only parameter. On `helm install`,
  the repmgr image's entrypoint bakes `shared_preload_libraries = 'repmgr'` directly at
  `initdb`; the chart's merged value (repmgr + any operator-declared libraries + pgaudit)
  lives in a conf.d file that was only spliced into `postgresql.conf` by the `postStart`
  hook, after postgres was already accepting connections -- too late for a
  restart-only GUC, and nothing forced the restart a `helm upgrade`'s config-checksum
  rolling restart would have provided. The `databases-roles`/`audit-extension` hook Jobs
  then failed `CREATE EXTENSION ... must be loaded via shared_preload_libraries`, and
  (per `hook-delete-policy: before-hook-creation,hook-succeeded`) sat failed rather than
  retrying. Pre-existing, not introduced by #303 -- confirmed the identical failure on
  unmodified 1.10.2 with only `postgresql.audit.enabled: true` set.

  Fixed at the source: `repmgr.image.tag` bumped to `trixie-5.5.0-31`, whose entrypoint
  now wires the chart's conf.d `include_dir` into `postgresql.conf` at `initdb` time --
  before its own bootstrap `pg_ctl start` -- so the merged `shared_preload_libraries` is
  active from the very first postmaster start on a fresh install, no restart required.
  Verified live on a fresh `helm install` for both the `pg_cron` recipe above and
  `postgresql.audit.enabled: true`. `etcd.rbac.bootstrapImage.tag` bumped alongside it,
  same lockstep requirement as always.

## 1.10.2 - 2026-08-14

### Fixed

- **`copy-ext` could silently overwrite `copy-base-ext`'s libs with a mismatched build
  (#302).** When `repmgr.enabled=true` and `postgresql.extensions.enabled=true`,
  `copy-base-ext` populates `ext-lib`/`ext-share` from the repmgr image -- the image that
  actually runs the server -- and `copy-ext` then ran an unconditional wildcard `cp` from
  `postgresql.image` on top of it. If the two images drifted to different PostgreSQL point
  releases (`postgresql.image` is often pinned to a floating tag), `copy-ext` silently
  replaced core libs such as `libpqwalreceiver.so` with a mismatched build, and every
  freshly-created pod failed to stream replication (`undefined symbol`) -- `ext-lib`/
  `ext-share` are emptyDirs, so this hit on every pod, not just the first. `copy-ext`'s
  copy is now `cp -n` (no-clobber): it can only add files the repmgr image doesn't already
  provide (e.g. `vector.so`), never overwrite one.

## 1.10.1 - 2026-08-11

### Fixed

- **Backport (#297): a scale-up could leave the cluster without a serving primary, or with a
  standby that never replicates.** Both affect agent mode -- the default since `1.0.0` -- from
  that release onward. Fixed on the 2.0.0 line first; backported here because they are
  data-availability bugs in a shipped release.

  Adding a replica (`postgresql.replicaCount` N -> N+1) also changes `REPMGR_NODE_COUNT`, which
  rolls every pod, so the new pod is created while the others restart. Two things could go wrong:

  1. **No serving primary.** The new pod could win the Lease before registering in
     `repmgr.nodes`. Once it promoted, no survivor held a record for it, so none could
     `repmgr standby follow` it -- it failed `unable to find record for intended upstream node`
     on every reconcile tick, and nothing served writes. *Fix:* a promote candidate now reads
     `repmgr.nodes` and, if it has no row of its own while a registered and reachable peer
     exists, releases the Lease instead of promoting. Conservative by design -- an unreadable
     registry, a cluster where nobody is registered, or an unreachable peer all still promote,
     because serving with degraded metadata beats refusing to serve.
  2. **A standby that never replicates.** The new pod's own `repmgr.nodes` copy is a snapshot of
     the primary taken *before* it registered, so it holds no row for itself and cannot obtain
     one -- receiving it requires replicating, and repointing replication is what needs it. It
     failed `unable to retrieve record for local node` forever, `Running` but never `Ready`.
     *Fix:* that specific error now triggers a re-clone from the current primary, replacing data
     and metadata together.

  The re-clone is scoped by error string, not by state, and the distinction matters: a missing
  **upstream** record is the ordinary post-failover case where the target has simply not promoted
  yet, and escalating there would demote and re-clone a healthy standby. A unit test asserts the
  upstream variant does not escalate.

  **Image:** the fix is in the agent binary, so this release republishes the repmgr image as
  `trixie-5.5.0-30` and pins `repmgr.image.tag` to it (along with `etcd.rbac.bootstrapImage.tag`,
  which runs the same image and must move in lockstep). A 1.10.1 left pointing at `-29` would
  have carried the chart change without the fix.

  Verification: reproduced and fixed on a live KinD cluster on the 2.0.0 line, whose `upgrade`
  suite scales an agent-mode cluster up. **1.x's own `upgrade` suite pins `failoverMode: repmgrd`**
  (whose `OrderedReady` serialises pod creation and closes the window), so the 1.x suites prove
  no regression rather than proving the fix. The agent binary is identical to the verified one.

## 1.10.0 - 2026-08-02

### Added

- **`control.restore`'s job-create grant is now bounded by a `ValidatingAdmissionPolicy`**
  (#279), rendered by default whenever `repmgr.agent.control.restore.enabled` is set.

  1.9.0 shipped API-driven restore with an honest warning rather than a fix: triggering a
  restore needs `create` on `jobs`, RBAC **cannot** restrict a create by `resourceName`, and
  so the grant let anything holding the database pods' ServiceAccount token create arbitrary
  Jobs in the namespace — naming any ServiceAccount, with no separate permission check. On a
  token mounted beside a PostgreSQL that runs user-supplied SQL, that is a namespace-wide
  privilege-escalation primitive, and the documented advice was to leave the feature off.

  The missing restriction is content-based, which is a layer RBAC does not reach.
  `ValidatingAdmissionPolicy` is exactly that layer, in-tree and GA since Kubernetes 1.30 —
  no webhook, no serving certificate, nothing that can be down. The policy polices **one
  subject**, this release's ServiceAccount, and requires of every Job it creates:

  | Pinned | Why |
  |---|---|
  | `metadata.name` == the agent's one deterministic Job name | the `resourceName` restriction RBAC refused to give — `create` collapses to a single object |
  | `pg-ha/restore=<fullname>` label | provenance, and it fails closed if chart and policy drift |
  | `serviceAccountName` == the release's own SA | removes the escalation; what is left is "the privileges I already hold" |
  | `automountServiceAccountToken: false`, stated explicitly | makes SA-naming moot: the pod gets no token |
  | no `hostNetwork` / `hostPID` / `hostIPC`, no explicit `nodeName`, only this release's `priorityClassName` | no escape to the node, no placing the pod by hand, and no claiming a high-priority class to make the scheduler preempt this release's own postgresql pods |
  | the **pod's own labels**, limited to this release's restore labels plus the batch controller's | a restore pod labelled `component=postgresql` would join the write Service's endpoints — Ready immediately, since it has no readiness probe — and receive application traffic and credentials |
  | no `manualSelector` | the Job's selector and identity labels stay server-assigned |
  | one container, no init or ephemeral containers, running this release's repmgr image | bounds what code enters the cluster on this token |
  | `command` == this release's restore entrypoint, no `args`, no `lifecycle` hooks | the image pin alone is weak: the postgresql container already runs this image against this volume, so without this the Job is "run anything as the database's uid with the live PGDATA mounted" |
  | this release's pod and container `securityContext` | no `privileged`, no `runAsUser: 0`, no added capabilities — otherwise the Job is a strictly *larger* privilege set than the token started with |
  | requests and limits present; `parallelism`/`completions` ≤ 1 | the one permitted Job name is otherwise a repeatable way to fill the namespace quota and evict the database's own pods |
  | volumes limited to the three the restore template renders | with the token gone, mounting another workload's Secret was the remaining way out — this closes it, along with `hostPath` and projected tokens |
  | no `envFrom`; `valueFrom` limited to the downward API and the release's own Secrets | the same bound for env |

  The security contexts, resources and command are pinned to **what this release's values
  render**, not to a fixed hardened profile, so changing `postgresql.containerSecurityContext`
  moves the pin with it — a chart that denied its own restore Job would be worse than no
  policy.

  Every other creator of Jobs — humans, GitOps controllers, the CronJob controller, other
  workloads — is **unaffected**; that direction is asserted in the KinD suite alongside the
  denials, because a policy that broke every other controller in the namespace would be
  worse than the hole it closes.

  `failurePolicy: Fail` is load-bearing: under `Ignore` an evaluation failure would
  silently re-open the hole. In the same spirit the grant and its bound cannot be separated
  — rendering the RBAC without the policy **fails the render** unless you say so in values:

  ```yaml
  repmgr:
    agent:
      control:
        restore:
          enabled: true
          allowedClientCNs: [dba-break-glass]
          admissionPolicy:
            enabled: true            # default
            acknowledgeUnbounded: false
  ```

  **What it does not bound**, stated plainly because it decides whether the feature belongs
  on a given cluster: the restore *parameters*. Anything holding the token can still create
  the one permitted Job with its own `TARGET`/`BACKUP_SET`/`FORCE` — this release's own
  restore, over the live PGDATA, without presenting a certificate to the control API. A
  restore over the live data directory is the operation being exposed, so admission has
  nothing left to reject; pgBackRest's `postmaster.pid` interlock still means this needs the
  StatefulSet already scaled to 0.

  Nor is the command pin a sandbox: bash reads `$BASH_ENV`, and an actor who already runs code
  in the postgresql container can write a file into PGDATA, which this Job mounts. That
  reaches uid 101 with no token and only this release's volumes — the privileges already held,
  which is the bar — but the image, security-context, volume and env pins are what hold it,
  not the command pin alone.

  So the policy turns "namespace-wide privilege escalation from a SQL injection" into "an
  unauthenticated trigger for this release's own restore". That is a large reduction, and it
  is what makes the feature defensible rather than advisory — but where untrusted SQL runs
  and an unscheduled restore would itself be a serious incident, leaving `control.restore`
  off remains the right answer.

- `pgbackrest.restore.mode=cronjob` now renders `jobTemplate.metadata.labels` with
  `pg-ha/restore=<fullname>`. Both `kubectl create job --from=cronjob/...` and the control
  API's clone copy jobTemplate labels onto the Job they create, and nothing else does — so
  a cloned restore Job is now selectable (`kubectl get jobs -l pg-ha/restore=<fullname>`)
  where before it carried no labels at all. Deliberately *not* the full `app.kubernetes.io`
  set: a Job the agent creates is not Helm-managed, and claiming otherwise invites a GitOps
  controller to prune it mid-restore.

### Upgrading

- **Requires Kubernetes ≥ 1.30 and cluster-scoped `create` on
  `admissionregistration.k8s.io` (`ValidatingAdmissionPolicy`, `ValidatingAdmissionPolicy-
  Binding`) — but only if you enable `repmgr.agent.control.restore`.** These are this
  chart's first cluster-scoped objects; a default install renders none of them, so a
  namespace-limited installer is unaffected unless it opts into restore triggering.
- Already running `control.restore.enabled: true` on 1.9.0 and cannot render cluster-scoped
  objects (or are below 1.30, or manage one policy centrally)? Set
  `repmgr.agent.control.restore.admissionPolicy.enabled: false` **and**
  `acknowledgeUnbounded: true` to keep 1.9.0's behaviour, which the render otherwise
  refuses. Without the API the render **fails** rather than letting the apply abort halfway
  with "no matches for kind ValidatingAdmissionPolicy", so an upgrade cannot leave a release
  half-applied. The precondition checked is the presence of `admissionregistration.k8s.io/v1`,
  not the reported Kubernetes version: with no cluster to query, `.Capabilities.KubeVersion` is
  the *helm client's* built-in version (3.14 reports v1.29), so a version floor would break
  every `helm template` run by an older helm regardless of the target cluster.
- Values interpolated into the policy's CEL expressions (`pgbackrest.existingSecret.name`,
  `pgbackrest.repoEncryption.existingSecret.name`, the image reference, `fullnameOverride`)
  are now charset-validated at render time. A name containing a quote or whitespace fails
  the render with the offending value named, instead of producing a policy the API server
  rejects — or, worse, one whose validation is a tautology.
- A cluster whose **mutating** admission rewrites `Job` objects (sidecar injectors act on
  Pods and are unaffected) can make the cloned Job stop matching a pin. The denial names the
  exact field, and the same two values turn the policy off.

## 1.9.0 - 2026-08-01

### Added

- **Authenticated control REST API for the agent** (#276), off by default. Agent mode only.

  The existing pause and switchover runbooks are `kubectl annotate` calls on the marker
  ConfigMap. They stay the reference, and they need no extra machinery — but they cannot
  check a request before accepting it: `kubectl annotate ... switchover-target=<pod>`
  succeeds even when the pod does not exist, is on a divergent timeline, or is far behind,
  and you find out by reading logs. Nor can they tell you each member's replication
  position, or *why* the loop is not doing what you expected.

  ```yaml
  repmgr:
    failoverMode: agent
    agent:
      control:
        enabled: true
        tls:
          existingSecret: pg-control-tls    # tls.crt, tls.key, ca.crt — all three
        allowedClientCNs: [ops-admin]       # optional; empty = any cert the CA signed
  ```

  It is a **facade, not a second control plane**: pause/switchover write exactly the marker
  annotations kubectl writes, and the reconcile loop remains the sole authority for when
  anything happens — so kubectl and the API stay equivalent. What it adds is preflight
  validation, a synchronous answer, and state that existed nowhere else:
  `GET /v1/cluster` reports every member's timeline/LSN **and the loop's latest decision
  with its reason**, which was previously log-only.

  Surface: `GET /v1/status`, `GET /v1/cluster`, `POST /v1/pause`, `POST /v1/resume`,
  `POST /v1/switchover`, `DELETE /v1/switchover`, `POST /v1/restart`, `POST /v1/reload`,
  `POST /v1/reinitialize`, `GET /v1/backups`, and `GET`/`POST`/`DELETE /v1/restore`.

  `POST /v1/reinitialize` rebuilds a standby that cannot rejoin on its own, replacing the
  "delete the PVC and the pod" runbook: it stops PostgreSQL and empties the data directory,
  and the loop's ordinary empty-data clone path does the rebuild — no second clone
  implementation. **Replica only**: it refuses on the lease holder (checked against the
  lease, not a cached role), refuses a node running read-write without the lease, refuses
  while paused (a paused loop would never re-clone), and requires `force: true`. The wipe
  itself refuses anything that is not an initialized data directory, or that still has a
  `postmaster.pid`. No extra RBAC.

  Security posture:

  - **mTLS only** — no token, no password, no plaintext, TLS 1.3, and reads are
    authenticated too. Enabling it without all three TLS files **fails the render**, so you
    cannot end up with an unauthenticated mutating port. The material is re-read per
    handshake, so a rotated (cert-manager-renewed) Secret needs no pod restart.
  - **Its own port** (`9201`), never `9200`. The metrics port gains no route, and a render
    guard refuses `control.port: 9200`. Under `networkPolicy.enabled` the control port gets
    no ingress rule at all — deny-by-default in an allowlist policy — with
    `networkPolicy.agentControl.extraIngress` to admit a named client. `kubectl
    port-forward` bypasses the pod network on most CNIs, so it stays the path for humans.
  - **No control Service**: node-local verbs act on whichever pod answers, so each request
    must name the pod it addresses (`{"node": "..."}`) and is refused with 409 otherwise.
  - Structured audit line per mutating call (client CN, certificate fingerprint, serial),
    plus `pg-ha/paused-by` and `pg-ha/switchover-requested-by` on the marker so the
    provenance survives a pod restart and shows in `kubectl describe`.
  - New read-only metrics: `pg_ha_agent_control_requests_total`, `_control_rejected_total`,
    `_control_intents_total`, `_control_restore_requests_total`.

  Enabling the API adds **no Kubernetes RBAC**.

- **API-driven PITR restore** (`repmgr.agent.control.restore`, #276), a **separate** opt-in
  on top of the API, because it is the one verb that widens the database pods' privileges:
  `create` on `jobs` cannot be restricted by `resourceName`, so the grant lets anything
  holding the pods' ServiceAccount token create arbitrary Jobs in the namespace — and a
  Job's pod may name any ServiceAccount. That is a namespace-wide privilege-escalation
  primitive on a token mounted beside a PostgreSQL that runs user-supplied SQL, and the
  kubectl path (`kubectl create job --from=cronjob/...`) needs none of it. It is documented
  in the README and in `rbac.yaml` itself; leave it off unless the trade is worth it.

  What the grant buys is choosing the recovery point **in the request**
  (`targetType`/`target`/`backupSet` are applied to the Job the agent creates), so an
  operator can recover to an arbitrary timestamp with one call. The kubectl `mode: cronjob`
  runbook cannot: it needs the target in values and a `helm upgrade` first. Without that
  requirement, use the kubectl path and skip the RBAC entirely.

  What bounds it:

  - The Job is a **verbatim clone** of the rendered restore CronJob's `jobTemplate` —
    identical to `kubectl create job --from`, so image, ServiceAccount (token still
    unmounted), security contexts, volumes and secret references all come from the release.
    Only `TARGET_TYPE`/`TARGET`/`BACKUP_SET` are overridden, and an env backed by
    `valueFrom` is never overwritten (a `secretKeyRef` cannot become a request-supplied
    literal).
  - **Which volume is restored into is not an API decision** — that is
    `pgbackrest.restore.podOrdinal`, rendered into the Job; the body may only confirm it.
  - The API **never sets pgBackRest's `--force`**, so the `postmaster.pid` interlock stays
    armed; the stale-pid bypass remains a reviewable values change.
  - Requires `force: true`, `confirm: "<statefulset name>"`, a **second** restore-only CN
    allowlist, and a **paused** cluster; one call then verifies, stops the local postmaster
    and creates the Job.
  - It deliberately does **not** scale the StatefulSet — scaling to 0 deletes every agent,
    including the one that would report progress — and returns the remaining commands in
    `nextSteps`. Net effect: it removes the `kubectl create job --from` step, nothing more.
    Whether a scale-down is needed at all depends on scheduling: ReadWriteOnce binds a
    volume to a NODE, so a Job co-scheduled with the target pod starts immediately. What
    keeps a restore off a live data directory is the required pause plus the postmaster
    stop, not the scale-down.
  - **The runbook ends with `POST /v1/resume`, and it is not optional.** Maintenance mode
    makes the reconcile loop a no-op, so a restored node scaled back up while still paused
    never starts PostgreSQL and never goes Ready. The API will not clear an operator's
    pause on its own; `nextSteps` lists the resume as a required step.

  Progress and provenance: `restore.sh` now records the outcome of each restore attempt to
  `pgbackrest-restore.status` beside PGDATA (backup set, target, exit code, post-restore
  control-file state, requester). It outlives the Job and its logs, and the API returns it
  as `lastRestore` on `GET /v1/status` — which also doubles as a record of where a data
  directory came from. `GET /v1/status` additionally reports **WAL-replay progress**
  (`recovery.replayLsn`, `replayLagBytes`, `lastReplayTime`), which for a PITR is usually
  the phase you are waiting on. Live file-copy percentage needs
  `restore.readPodLogs: true`, which grants namespace-wide `get pods/log` and only helps
  when an agent is still running (`podOrdinal > 0`); it is off by default.

### Fixed (pre-release, from the review of this feature)

- The reinitialize replica-only gate now reads the leader lease **live from the DCS** and
  additionally requires that the durable primary marker not name this pod, instead of
  trusting the once-per-tick snapshot. The control listener starts before the first
  reconcile tick, when that snapshot is all-zero, so the previous check could have admitted
  a wipe of the actual primary during startup. A pod that has not published an observation
  yet is refused outright. The restart interlock for the serving primary reads the live
  lease for the same reason.
- `POST /v1/resume` and `POST /v1/reinitialize` now refuse while a restore Job is `pending`
  or `running` (fail-closed if that cannot be determined). The restore runbook ends in a
  resume, so resuming too early would have let the reconcile loop start PostgreSQL on a data
  directory pgbackrest was still rewriting.
- `POST /v1/restore` overrides only the recovery-point fields the request actually
  specifies. It previously blanked a `pgbackrest.restore.targetType`/`target` pinned in
  values whenever a request omitted them, restoring the latest backup and replaying all WAL
  instead of stopping at the reviewed point in time. The response now reports
  `effectiveTargetType`/`effectiveTarget`/`effectiveBackupSet`, read back from the created Job.
- The data-directory wipe now distinguishes a **stale** `postmaster.pid` (its process is
  gone -- what a crashed postmaster leaves behind, and precisely the replica reinitialize
  exists to rebuild) from a live one, which remains a hard refusal. An unreadable or
  malformed pid file is treated as live.
- `replace: true` waits for the previous restore Job to be fully deleted before creating its
  replacement. Foreground propagation returns while the object still exists behind its
  finalizer, so the create hit `AlreadyExists` -- after the handler had already stopped
  PostgreSQL.
- A failed restore no longer overwrites the data directory's provenance: `restore.sh` keeps
  the previous record's backup set and target (many failures copy nothing at all) and
  records the failed attempt separately as `attemptedTargetType`/`attemptedTarget`/
  `attemptedBackupSet`. A mistyped PITR target previously erased where the data really came from.
- `hasData` is reported only for the node answering the request and is absent for peers,
  rather than being emitted as `false` for every peer -- including a primary plainly holding
  data, and a replica whose re-clone had in fact completed.
- The restore feature gate now emits its audit line and increments
  `pg_ha_agent_control_rejected_total` itself. It short-circuits the authorization check by
  design (so a missing values flag reports as such rather than as a 403), which meant
  probing of the most destructive routes left no trace in the audit log or metrics.
- `GET /v1/restore` is feature-gated like the mutating restore routes: it needs the `get
  jobs` grant that is rendered only when restore is enabled, so it previously failed with a
  Forbidden error that read as a broken Role.
- The control server's response-write deadline is derived from the request budget instead of
  being a fixed 90s, so a long intent on a release with a wide reconcile interval returns
  its 504 or 200 rather than a dropped connection.
- The switchover preflight compares the candidate's timeline against the **lease holder**
  rather than against whichever pod answered the call. There is no control Service, so a
  request addressed to a standby that was itself behind on timelines would refuse a valid
  candidate and — the dangerous half — accept one on the stale timeline, yielding a `202`
  the loop then silently sat on. An unreadable primary timeline, an invisible lease holder
  and a cluster with no lease holder are now all refusals instead of a skipped comparison.
- Node-local operations now run under the **request's** deadline instead of the agent's
  process-lifetime context. A postmaster that ignored SIGINT would otherwise hold the
  operation mutex indefinitely: the reconcile loop stops ticking and the leadership fence
  blocks behind the same mutex, so a node that comes back read-write is never demoted. The
  stop now escalates to SIGKILL exactly as the fence path does; a restart still brings
  PostgreSQL back up afterwards, while a forced stop for a restore is reported as a failure
  (SIGKILL leaves the `postmaster.pid` that guards the data directory).
- The `lastRestore` record is removed when the data directory stops being what it describes
  — a reinitialize wipe, or a clone by the reconcile loop. It lives beside PGDATA so it can
  outlive the restore Job, which meant a wipe could not reach it and a rebuilt replica went
  on reporting a backup set as the provenance of data streamed from the primary.
- `restore.sh` keeps the attempted recovery point in separate variables instead of packing
  it into one `|`-delimited string, so an operator- or API-supplied target containing that
  character no longer corrupts the failure record.
- Request bodies with trailing content after the JSON object (`{"force":true} {...}`) are
  rejected rather than silently half-read, matching the existing unknown-field strictness.
- Dropped `truncated` from the restore-progress payload: nothing ever set it, so it
  advertised a signal the agent does not produce.

### Changed

- The agent's read-only `:9200` server now sets HTTP timeouts (read-header/read/write/idle)
  and a header-size cap. It had none, so a client opening connections without sending
  requests could accumulate goroutines in the process that supervises PostgreSQL.

## 1.8.1 - 2026-07-31

### Added

- **PostgreSQL 17 is selectable; 18 remains the default** (#269). The chart was already
  written to be major-agnostic — `postgresql.majorVersion` and `repmgr.image.majorVersion`
  both exist, and the render guard only enforces that they *agree* — but the repmgr image
  was built PG18-only. Because repmgr mode takes the server binaries from that image,
  pointing `postgresql.image` at another major was **silently inert**, and the only way to
  run one was to fork the image.

  The major is now a build argument (`PG_MAJOR`, default 18) and each release publishes one
  multi-arch, attested, cosign-signed manifest per major:

  | Tag | PostgreSQL |
  |-----|------------|
  | `trixie-5.5.0-29` | 18 — the default; what every unsuffixed pin resolves to |
  | `trixie-5.5.0-29-pg18` | 18, named explicitly |
  | `trixie-5.5.0-29-pg17` | 17 |

  To run 17, move `postgresql.majorVersion`, `repmgr.image.majorVersion` and
  `repmgr.image.tag` together — see
  [Choosing the PostgreSQL major](README.md#choosing-the-postgresql-major). Reasons it may
  matter: repmgr 5.5.0's upstream install requirements list PostgreSQL **13–17, not 18**
  (the 18 default rests on distro packaging rather than an upstream support claim); PGDG
  extension availability varies by major; and `pg_dump` output is not guaranteed to load
  into an older server, so the major a cluster is created on constrains where its data can
  later go. PostgreSQL 17 is supported upstream until 2029-11-08.

  **This is a create-time choice, not an upgrade path** — a new-major server refuses to
  start on an old-major `PGDATA`, so moving an existing cluster means a dump/restore into a
  fresh release.

- **Both majors run the whole live suite in CI**, not a spot-check: every suite (failover,
  chaos, pgBackRest restore, TLS, pgpool, etcd DCS, repmgrd→agent migration) now runs on 17
  as well as 18, via a `pg_major` matrix axis and `pg/tests/set-pg-major.sh`. Each published
  image is also started and verified before release — server version, `repmgr`/`repmgrd`
  resolving at 5.5.0, and `pgaudit` actually loading — so `audit.enabled=true` works on
  either major.

### Changed

- `repmgr.image.tag` / `etcd.rbac.bootstrapImage.tag` → `trixie-5.5.0-29`, which carries the
  `PG_MAJOR` parameterisation. **An unchanged values file produces an unchanged result**:
  the unsuffixed tag is still PostgreSQL 18, and the render is byte-identical apart from
  the tag itself.

### Fixed

- The major-mismatch render guard was only tested in one direction (moving
  `postgresql.majorVersion`). It is now asserted symmetrically, so moving
  `repmgr.image.majorVersion` alone — the direction the parameterisation makes possible —
  also fails fast instead of running one major while building extension paths for another.

- **The image tag now has to agree with the major it claims.** The `-pgNN` suffix is what
  actually selects the server major, but the guard above only compared two hand-typed
  `majorVersion` values — so moving the tag without the majors (or the reverse) rendered
  cleanly and ran the wrong major: a crash-looping extension init container with
  `extensions.enabled=true`, a silently wrong major without it. The render now fails when a
  `-pgNN` tag disagrees with `repmgr.image.majorVersion`, and `PG_MAJOR` is passed to every
  container running the repmgr image so the unsuffixed case is caught too — the entrypoint
  and the agent refuse to start an image that does not bundle the requested major, naming
  both sides.

- `etcd.bootstrapImage.tag` was never read: the etcd subchart takes it at
  `rbac.bootstrapImage`, so the RBAC-bootstrap Job stayed on the subchart's older default
  (`trixie-5.5.0-24`) while every other container moved with the chart. Anyone mirroring
  only the tags the chart names got ImagePullBackOff on the post-install Job, leaving etcd
  auth disabled and every agent with full-keyspace access. Now nested correctly, so one tag
  covers the whole render.

- The repmgr image's shell layer and Go agent hardcoded `/usr/lib/postgresql/18/bin` in
  seven places, so the bindir is now derived from `PG_MAJOR` (`repmgr-common.sh` exports
  `PG_BINDIR`; the agent derives it from `config.PGMajor`). The agent refuses to start when
  that bindir holds no `postgres` binary, rather than failing mid-reconcile after taking the
  lease.

- The agent's vendored `google.golang.org/grpc` (1.79.3 → 1.82.1) and `golang.org/x/text`
  (0.37.0 → 0.39.0) carried two advisories that `govulncheck` reports as reachable from
  the etcd DCS and Service-patch paths: **GO-2026-6061** (xDS RBAC / HTTP-2 transport) and
  **GO-2026-5970** (infinite loop on invalid input). Bumped and re-vendored; no agent
  source changed.

- The live suites pinned `repmgr.image.tag: trixie-5.5.0-27` in their fixtures while the
  chart shipped `-28`, so they pulled an older published image instead of the one CI
  builds from source. `set-pg-major.sh` now retargets every fixture at the chart's own
  tag before a suite runs, on both majors — so CI tests the image it built. The two suites
  that deliberately pin an *older released* image (the repmgrd→agent migration and the
  repmgrd TLS leg) are marked `set-pg-major: keep` and left alone on the default major, so
  retargeting does not quietly turn "upgrade from a published image" into "upgrade an image
  to itself"; on a non-default major, where no older published image exists, they are
  retargeted with a logged note that the coverage does not apply there.

## 1.8.0 - 2026-07-31

### Added

- **`pgbackrest.bootstrap.*` — automatic recovery from a lost PVC** (#266). Losing replica 0's
  volume was quietly the worst kind of outage: the pod came back, the entrypoint found an empty
  data directory, and it `initdb`'d a **brand new empty cluster**. The backups were intact in S3,
  the live database was empty, and nothing failed loudly. Set `pgbackrest.bootstrap.enabled=true`
  and an init container (before `repmgr-init`) seeds an *empty* PGDATA from this release's own
  repository; PostgreSQL then replays the archived WAL on startup and promotes. A lost volume
  self-heals with no operator action.

  It needs no changes to the repmgr image: once PGDATA is populated, `init-repmgr.sh` defers the
  start decision and the entrypoint skips `initdb`, so recovery follows the same path as a
  scale-up after the #226 restore Job.

  **Safe to leave enabled** — it only ever writes into an *empty* data directory:
  - empty + repository has backups → restore, write a completion marker, replay WAL on startup;
  - empty + repository has **no backup yet** → do nothing, so a normal first install proceeds
    (`restore` exits non-zero with no backup, and Kubernetes retries a failed init container
    forever, so this case is the difference between "works" and "no pod ever starts");
  - empty + repository **unreachable** → **fail loudly**, pod stays in `Init`. The backup state
    is unknown, and initializing an empty cluster then would destroy a probably-recoverable
    database. Reached only when PGDATA is empty, so a pod rescheduled with an intact volume
    never depends on S3 being reachable;
  - already initialized → refuse to touch it, marker or not. An ordinary restart, rollout or
    re-schedule can therefore never re-restore over a running cluster;
  - partially restored (an attempt that died mid-flight) → resume with `--delta`, which is what
    makes the init container safe for Kubernetes to retry;
  - any replica other than 0 → nothing; standbys are cloned from the primary by repmgr.

  The marker at `$PGDATA/.pgbackrest-bootstrap-complete` records the stanza, backup set, target
  and system identifier. It lives inside PGDATA on purpose: it shares the volume's lifecycle, so
  losing the volume clears it exactly when a fresh bootstrap becomes correct again.

  Orthogonal to `pgbackrest.restore` (#226) and combinable with it — `bootstrap` populates an
  empty directory automatically, `restore` overwrites a live one under operator control. Also
  supports `bootstrap.targetType`/`target` and `bootstrap.backupSet`, with fail-fast guards for
  the target pair and for the `pgbackrest.enabled` + `postgresql.persistence.enabled`
  prerequisites.

  Verified by `make -C pg test-pgbackrest-bootstrap`, which deletes replica 0's PVC outright and
  asserts the **same** cluster returns — the PostgreSQL system identifier is unchanged, which a
  fresh `initdb` could not produce — then restarts the pod and asserts the bootstrap does not run
  a second time.

## 1.7.0 - 2026-07-31

### Added

- **`pgbackrest.restore.*` — a first-class PITR restore resource** (#226). The manual
  restore runbook made the operator hand-build an entire pod spec via `kubectl run
  --overrides='{…}'`: ~30 lines of inline JSON reconstructing the ServiceAccount, security
  contexts, the data PVC mount, the pgbackrest ConfigMap mount and the S3 credential env —
  all of which the chart already knows how to render. Set `pgbackrest.restore.enabled=true`
  and it ships that spec for you, and the runbook becomes four ordinary commands:

  ```bash
  kubectl scale statefulset my-postgres-pg --replicas=0
  kubectl wait --for=delete pod/my-postgres-pg-0 --timeout=5m
  kubectl create job --from=cronjob/my-postgres-pg-pgbackrest-restore restore-now
  kubectl wait --for=condition=complete job/restore-now --timeout=30m
  kubectl scale statefulset my-postgres-pg --replicas=2
  ```

  The resource carries the `-repmgr` ServiceAccount (so `s3.keyType: auto` works) with its
  API token unmounted, the postgresql pod/container security contexts, the
  `data-<fullname>-0` PVC and `<fullname>-pgbackrest` ConfigMap mounts, the S3 and
  repo-encryption credentials, and runs `pgbackrest restore --delta`. It reuses the #38
  validation plumbing, but needs no `pg1-path` override: the mounted `pgbackrest.conf`
  already points at the live PGDATA.

  Notable properties:
  - **Enabling it restores nothing.** It renders an *inert* resource — by default a
    suspended CronJob carrying a schedule that can never fire — so it can be left enabled
    and cloned when disaster strikes, without a `helm upgrade` mid-incident. The
    destructive scale down/up stays an explicit operator action.
  - **Two delivery modes** (`restore.mode`): `cronjob` (default) for
    `kubectl create job --from`, where the resource belongs to the release and a GitOps
    controller sees no stray object; or `job`, a bare Job to render on demand with
    `helm template -s … | kubectl apply -f -` when the point-in-time target must be passed
    inline (`restore.nameSuffix` gives a retry a fresh name, since Jobs are immutable).
  - **It never starts PostgreSQL.** WAL replay and promotion happen when the StatefulSet is
    scaled back up, under the normal chart entrypoint.
  - **No Kubernetes API access is needed to be safe.** pgbackrest itself refuses to restore
    while `$PGDATA/postmaster.pid` exists, so "did you actually scale down?" is enforced
    without an RBAC-carrying token. `restore.force` covers the one legitimate exception, a
    stale pid file left by a crash.
  - PITR target wiring (`restore.targetType`/`target`, the same enum as `validation`, with
    a template `fail` for the "target required once targetType is set" rule), plus
    `restore.backupSet` (`pgbackrest --set`) to pin a specific backup set, and fail-fast
    guards for the two prerequisites (`pgbackrest.enabled`, `postgresql.persistence.enabled`).

  Covered by template tests and by two end-to-end suites, both of which destroy the data
  directory outright and recover it from S3 through the documented runbook:
  - `make -C pg test-pgbackrest-restore` — single node, plus the #38 validation phase;
  - `make -C pg test-pgbackrest-restore-ha` (new) — primary + streaming standby. It restores
    the primary out from under a live standby and confirms the standby rebuilds itself: the
    restored primary comes back on a new timeline, the standby's init container detects the
    mismatch (`Timeline mismatch (local: 1, primary: 2), re-cloning...`), re-clones via
    `repmgr standby clone`, and resumes streaming — with no PVC deletion and no operator
    action. The README documents this as verified behaviour rather than an assumption.

### Changed

- The README's Point-in-Time Recovery runbook is now the four-command flow above; the
  `kubectl run --overrides` pod spec is gone, and the duplicate (and misleading — it had no
  pod to run `pgbackrest` in) PITR recipe in the troubleshooting section now points at it.

## 1.6.0 - 2026-07-30

### Added

- **`postgresql.extraVolumes` / `postgresql.extraVolumeMounts` / `postgresql.extraEnv`**
  (#262) — generic pod-spec passthrough for the postgresql container. Lets an operator
  mount an arbitrary `Secret`/`ConfigMap` as a file that is byte-identical on the primary
  and every standby, without a per-use-case chart change. The motivating case is the
  pgsodium server root key (Supabase Vault) read via `pgsodium.getkey_script`: it must be
  identical across replicas so a promoted standby can still decrypt `supabase_vault` after
  a failover. `extraVolumes` render into the pod template; `extraVolumeMounts` and
  `extraEnv` onto the postgresql container. All default to `[]` (no change to rendered
  output when unset). See the README, "Mounting an extra file on every replica".

  The three values are validated at render time (`pg.validateExtraPassthrough`), keeping
  the chart's fail-fast convention — each plausible mistake would otherwise be a silent
  runtime failure or an apply-time API rejection:
  - each must be a **list** of objects (a map produced an opaque YAML parse error);
  - an `extraVolumes` name may not collide with a chart-managed volume — a `data`
    collision is silently discarded in favour of the volumeClaimTemplate (mount resolves
    into the PVC, expected file absent → CrashLoopBackOff with nothing to point at), and
    with persistence off the duplicate name is rejected by the API server;
  - every `extraVolumeMounts` entry must reference a declared `extraVolumes` entry
    (catches the `extraVolume:`/`extraVolumes:` typo, which `values.schema.json` cannot —
    `additionalProperties` is open — and which otherwise fails only at apply, leaving a
    live release in a failed state);
  - `extraEnv` may not reuse a chart-set env name (`PGDATA`, `POSTGRES_*`, `REPMGR_*`, …);
    duplicate env names are last-wins at runtime, so an override would silently shadow the
    chart/Secret value (wrong data directory, or cluster-wide auth failure).

### Fixed

- **An operator-set `postgresql.configuration.shared_preload_libraries` silently dropped
  `repmgr` whenever `postgresql.audit.enabled` was false**, disabling failover. The merge
  that preserves `repmgr` (and the operator's own libraries) previously ran only on the
  audit path, while `custom.conf` is loaded via `conf.d`'s `include_dir` *after* the repmgr
  image's own `postgresql.conf` — so a bare value overrode
  `shared_preload_libraries = 'repmgr'` and the postmaster started without the repmgr
  library: repmgrd/agent lost their repmgr functions and no standby was ever promoted.
  The merge is now unconditional in repmgr mode, emitted from an authoritative
  `repmgr-preload.conf` that sorts after `custom.conf`. Surfaced while reviewing #262,
  whose pgsodium use case requires exactly this setting. Behaviour is unchanged when audit
  is enabled, and in standalone mode (nothing to preserve) the operator's value still
  passes through `custom.conf` untouched.

## 1.5.0 - 2026-07-12

Requires the new repmgr image (`trixie-5.5.0-28`), which bundles the `pgaudit`
extension. The default `repmgr.image.tag` is bumped accordingly; pgaudit is inert
until `postgresql.audit.enabled` is set, so upgrading with audit off is a no-op
beyond the image pull.

### Added

- **pgaudit-based audit logging (`postgresql.audit.*`)** for compliance regimes
  (SOC 2, HIPAA, PCI-DSS, ISO 27001) that require a per-object record of who did
  what (#219). Opt-in and default-off: `audit.enabled=false` renders identically to
  1.4.3. When enabled, the chart adds `pgaudit` to `shared_preload_libraries`
  (keeping `repmgr` and any operator-declared libraries), renders the `pgaudit.*`
  GUCs into the postgresql ConfigMap, and creates the extension idempotently on the
  primary via a post-install/upgrade hook Job. Because `shared_preload_libraries` is
  a postmaster parameter, toggling audit triggers a controlled rolling restart via
  the existing config-checksum annotation. Knobs: `log` (audit classes),
  `logCatalog`, `logParameter`, `logRelation`, and `role` (object-level auditing via
  `pgaudit.role`). Requires `repmgr.enabled=true` (guarded at render time — the stock
  postgres image used in standalone mode has no pgaudit).

## 1.4.3 - 2026-07-11

Chart-only fix. No image change (`trixie-5.5.0-27`).

### Fixed

- **pgpool no longer wedges in a permanent crash loop after repeated container
  OOM kills.** pgpool allocates its connection-pool state as an `IPC_PRIVATE`
  SysV shared-memory segment. When the pgpool container is OOM-killed the pod (and
  its IPC namespace) survives, but SIGKILL can't run `shmctl(IPC_RMID)`, so each
  restart strands another ~136Mi segment. After enough cycles the pod cgroup fills
  and the kernel OOM-kills `runc init` before pgpool runs, leaving the pod
  recoverable only by deletion (#234). The pgpool container now runs `ipcrm -a`
  to reap orphaned segments before `exec`ing pgpool.

### Added

- **`pgpool.command`** — override the pgpool container startup command. Empty
  (default) keeps the chart's `ipcrm -a` reap + `exec pgpool` sequence (#234).

## 1.4.2 - 2026-07-05

Chart-only fix. No image change (`trixie-5.5.0-27`).

### Fixed

- **pgBackRest PITR restore-validation no longer fails when the primary raises a
  recovery-relevant GUC (e.g. `max_connections`).** PostgreSQL refuses to begin archive
  recovery with `hot_standby=on` unless the recovery instance's `max_connections`,
  `max_worker_processes`, `max_wal_senders`, `max_prepared_transactions` and
  `max_locks_per_transaction` are each `>=` the value the primary had when the WAL was
  written (recorded in `pg_control`). Those tunables live in the chart's `conf.d` overlay,
  which `validate.sh` strips along with the `include_dir` line — so the throwaway instance
  fell back to initdb defaults (`max_connections=100`, etc.) and
  the postmaster died at startup with *"recovery aborted because of insufficient parameter
  settings"*, failing the validation Job even though the backup itself was fully restorable. The script now reads the required minimums straight from
  `pg_controldata` (which reports exactly the primary values recovery checks against) and
  passes them as `pg_ctl` startup overrides, so validation stays green and self-adjusts if
  the primary is ever retuned. Inherited by `pgvector` via its symlinked template.

## 1.4.1 - 2026-06-30

Chart-only fix. No image change (`trixie-5.5.0-27`).

### Fixed

- **Backup integrity check no longer aborts on dumps larger than the pipe buffer (#230).**
  The `backup.enabled` (pg_dump → S3) integrity step (`mc cat … | pg_restore --list`) ran
  under `set -o pipefail`. `pg_restore --list` reads only the header + TOC at the front of a
  `-Fc` dump, so on any dump exceeding the OS pipe buffer (~64 KB — i.e. any real database)
  it exits 0 while `mc cat` is still streaming; `mc cat` was then SIGPIPE-killed (exit 141)
  and `pipefail` propagated that, aborting the Job *before* the staged `.tmp` object was
  promoted to its canonical `backup_<ts>.dump` name — so no usable backup was ever published
  and the CronJob never recorded a success. The check now disables `errexit`/`pipefail`
  around the pipe and inspects both ends via `PIPESTATUS`: `pg_restore` must succeed and
  `mc cat` may only exit `141` (SIGPIPE) — a genuine `pg_restore` parse failure **or** a
  real `mc cat` S3-read error both stay fatal, so a damaged dump is never published as
  verified. The integration test now seeds a table whose
  `-Fc` dump exceeds the pipe buffer so the SIGPIPE path is covered in CI. Inherited by
  `pgvector` via its symlinked template.

## 1.4.0 - 2026-06-26

Chart-only feature. No image change (`trixie-5.5.0-27`).

### Added

- **Declarative databases, roles & grants (#218).** New `postgresql.roles[]` and
  `postgresql.databases[]` turn the chart into a self-serve platform database: a
  post-install/upgrade hook Job idempotently creates the declared roles (LOGIN/NOLOGIN,
  `memberOf` group membership), databases (with `owner` + per-database `extensions`), and
  grants (database-, schema-, and `ALL_TABLES`/`ALL_SEQUENCES`-level, including
  `ALTER DEFAULT PRIVILEGES` for future objects) on the primary — replicated to standbys,
  re-applied on every upgrade and after a restore. Default-empty, so a minimal install is
  byte-identical to before. Passwords are sourced from Secrets and read into the Job via
  psql `\getenv` (never argv, never the ConfigMap); a chart-generated, upgrade-persisted
  password is minted per LOGIN role unless an explicit `passwordSecret` is given. Render
  guards (`pg.validateDatabasesRoles`) enforce identifier safety, uniqueness, reserved-name
  protection, owner resolution, and a GRANT-privilege allowlist so a value can never inject
  SQL. **GitOps caveat:** under `helm template` (ArgoCD) set an explicit `passwordSecret.name`
  for every role, since the chart-generated password relies on a cluster `lookup` that is
  empty during render. Inherited by `pgvector` via its symlinked template.

## 1.3.0 - 2026-06-26

Chart-only feature. No image change (`trixie-5.5.0-27`).

### Added

- **Automated pgBackRest PITR restore-validation (#38).** New opt-in CronJob
  (`pgbackrest.validation.enabled`) that, on a schedule, restores the pgBackRest
  repository into a **throwaway PostgreSQL inside the Job pod** (never the live cluster),
  replays the archived WAL to a consistent state, runs a sanity query, and exits — so an
  unrestorable or corrupt repository raises an alert continuously instead of being
  discovered during a real disaster. Read-only against S3; the throwaway PGDATA lives on
  an emptyDir discarded when the pod ends. Runs from the repmgr image (pgbackrest +
  matching PostgreSQL major) as the postgresql pods' ServiceAccount (so `s3.keyType=auto`
  works), with its token unmounted (it never calls the Kubernetes API). Supports an
  optional PITR target (`validation.targetType`/`target`); the default restores the latest
  backup set and replays all WAL. This is the physical-backup counterpart to the existing
  `backup.validation` job, which only restore-tests the legacy `pg_dump` path. Covered by
  the new `test-pgbackrest-restore` integration test (restore + WAL replay on kind/MinIO).

## 1.2.7 - 2026-06-26

Chart-only fix for the legacy `backup.enabled` (pg_dump → S3) path. No image change
(`trixie-5.5.0-27`).

### Fixed

- **Backup to AWS S3 failed when the secret access key contained `/` or `+` (#221).**
  #167 moved S3 credentials out of the `mc` argv (where they were visible in
  `/proc/<pid>/cmdline`) by percent-encoding them into an `MC_HOST_<alias>` URL, but `mc`
  then signed SigV4 requests with the *encoded* secret — so any key containing URL-reserved
  characters (common in real AWS keys) produced `The request signature we calculated does
  not match the signature you provided` and every upload failed. `backup.sh` and
  `validate.sh` now write a `0600` JSON credential document and load it via `mc alias
  import`, which feeds the **raw** secret to the signer while still keeping credentials out
  of the process argv. The integration test now runs the full backup → validation → restore
  path against a secret key containing `/` and `+` so a regression fails in CI.

## 1.2.6 - 2026-06-26

Image security refresh: repmgr image `trixie-5.5.0-26` → `trixie-5.5.0-27`. No chart
template or behavior change — only the bundled image is updated.

### Fixed

- **Bundled `kubectl` upgraded `v1.31.3` → `v1.36.2` to clear its image-scan CVEs.**
  kubectl 1.31.3 linked Go 1.22.8 and `golang.org/x/net` 0.26.0, which Trivy flagged as
  1 Critical (`CVE-2025-68121`, Go stdlib) plus ~24 High (Go stdlib / `x/net` / `x/oauth2`
  / `moby/spdystream`). The current release links a patched Go 1.25 stdlib and recent
  modules. kubectl is only used by the service-updater for core verbs
  (`get`/`patch`/`label`/`exec`/`rollout`), so the version skew is immaterial.
- **Debian security updates now applied at build time (`apt-get upgrade`).** The
  digest-pinned base shipped stale pre-installed packages; the build now picks up released
  fixes such as `libssh2` `1.11.1-1+deb13u1` (`CVE-2026-7598`, `CVE-2026-55200`, High).

The remaining image-scan findings are Debian packages with no upstream fix yet (the Perl
`CVE-2026-42496` / `CVE-2026-8376` Criticals, plus `libexpat1`/`curl`/`gnupg`/`ncurses`
Highs); they are tracked and will clear on a future rebuild once Debian ships patches.

## 1.2.5 - 2026-06-25

Chart-only correctness fixes for four edge cases in the repmgr/pgBackRest paths
(#211, #212, #213, #214). No image change (`trixie-5.5.0-26`).

### Fixed

- **`fix_user_auth` md5→scram migration silently no-op'd for users whose password contains
  a single quote (#211).** The init script passed the password via `psql -v p=...`; a `'`
  in the value broke psql's `:'p'` literal quoting, so the rehash failed and the migration
  never converged (the md5 pg_hba fallback masked it, so connectivity was kept). The
  password is now read from the environment with `\getenv` — the same injection-safe
  pattern the monitoring-user job already uses — so any password value is handled. Only
  affected `existingSecret` passwords; the chart's `randAlphaNum` generator never emits `'`.
- **pgBackRest cronjob could run the backup against a standby and silently skip it (#212).**
  Primary discovery took the first Ready endpoint from the write Service's EndpointSlices;
  during a failover + scale-down collision, stale EndpointSlices can briefly expose more
  than one Ready endpoint, and with `backoffLimit: 0` a backup that landed on a read-only
  pod was silently dropped for that schedule. The cronjob now validates every Ready
  candidate with `pg_is_in_recovery()` and runs the backup only against the confirmed
  read-write primary. The probe is `timeout`-bounded (a wedged mid-shutdown candidate
  can't hang the run) and retried once; candidates are validated in a deterministic
  (sorted) order; and the EndpointSlice lookup degrades to the actionable "no ready
  endpoint" error instead of a bare `set -e` abort. To avoid regressing the common
  single-node case, when exactly one Ready endpoint exists and its recovery state is
  merely unreadable (not a confirmed standby), the backup proceeds against it — matching
  the prior behavior — rather than being skipped on a transient probe failure; a
  confirmed standby is still never backed up.
- **Inconsistent `required` guard on the pgBackRest S3 secret name (#213).**
  `PGBACKREST_REPO1_S3_KEY_SECRET` (init env) and both keys in the pgbackrest sidecar
  referenced `pgbackrest.existingSecret.name` without the `required` wrapper that
  `PGBACKREST_REPO1_S3_KEY` already had. Functionally safe (the first `required` failed
  render first), but `required` is now applied consistently to every reference.
- **Unbounded ephemeral PGDATA when `persistence.enabled=false` (#214).** With the default
  empty `persistence.emptyDir.sizeLimit`, the `data` volume rendered as `emptyDir: {}`, an
  unbounded ephemeral volume a runaway DB/WAL could use to fill the node and evict
  co-tenants. The volume is now always bounded: `emptyDir.sizeLimit` falls back to
  `persistence.size` (the cap already declared for persistent mode) when unset, then to a
  10Gi floor if `persistence.size` is also blank, so the cap is never null.

## 1.2.4 - 2026-06-24

Chart-only fix for agent-mode pgpool instability at `postgresql.replicaCount: 0` (#207).
No image change (`trixie-5.5.0-26`); only affects `pgpool.enabled` + `repmgr.enabled` +
`repmgr.failoverMode: agent` deployments running primary-only.

### Fixed

- **Agent-mode pgpool churned `restarting myself` and dropped live primary connections
  when `postgresql.replicaCount: 0` (#207).** The pgpool ConfigMap unconditionally
  configured a second backend (`backend_hostname1`) pointing at the `-readonly` Service.
  With zero standbys that Service has no endpoints, so pgpool health-checked a backend that
  could never come up, repeatedly fired failover/failback events, and restarted itself --
  tearing down every client connection to the healthy primary on each cycle. Clients saw
  `EOF`/`unable to read data from DB node 0` even though node 0 was fine. The RO backend is
  now emitted only when `replicaCount > 0`; primary-only agent mode renders as a single
  RW backend (weighted 1) -- a valid, stable single-backend router.

## 1.2.3 - 2026-06-23

Chart-only fix for a postgres-exporter TLS regression (#204). No image change
(`trixie-5.5.0-26`); only affects deployments with `prometheusExporter.enabled` and
`prometheusExporter.sslmode` set to `verify-ca`/`verify-full`.

### Fixed

- **Exporter could not read the TLS CA under `sslmode=verify-ca`/`verify-full`, so every
  scrape failed with `permission denied` and `pg_up` stayed `0` (#204).** The CA secret
  was mounted whole at `defaultMode: 0400` (owner-read only); the exporter runs as a
  non-root UID with no `fsGroup`, so the root-owned `ca.crt` was unreadable. The scrape
  target stayed `up` (the `/metrics` endpoint returns 200 with `pg_up 0`), making it a
  silent monitoring blackout. The exporter's TLS volume now projects **only** the public
  `ca.crt` at a world-readable `0444` -- no `fsGroup` needed. The server cert `tls.crt`
  and private key `tls.key` are no longer mounted into the exporter (it never read them;
  the monitoring user is exempt from client-cert auth). Regression from the #110 mTLS work.

## 1.2.2 - 2026-06-22

Fixes a `pg_hba.conf` dual-authorship bug that broke md5-password authentication on
agent-mode standbys (#199). Image moves to `trixie-5.5.0-26`.

### Fixed

- **Agent-mode standbys could end up with a SCRAM-only `pg_hba.conf`, breaking
  md5-password clients (#199).** The agent wrote a SCRAM-only `pg_hba.conf` every boot
  while the chart's postStart hook layered an md5-first fallback on top; the two raced,
  and on a rejoined standby the agent won, leaving it SCRAM-only. With legacy md5-stored
  passwords, every TCP password auth into the standby then failed (exporter `pg_up=0`,
  pgpool `-readonly` backend auth failure, and a failover lockout if such a standby were
  promoted). The agent is now the **single author** of `pg_hba.conf` in agent mode: it
  writes the md5-first compat form (an md5 line above each scram rule, on the pod CIDR
  only -- never the mTLS clientcert catch-all, never `0.0.0.0/0`) on every node, so
  primary and standby are byte-identical. The postStart md5-fallback + re-hash now run
  only in repmgrd mode.
- **md5->scram managed-user re-hash now runs on failover-promotion, not just at boot
  (#199).** The re-hash moved into the agent and runs on promotion/boot-primary, so a
  node promoted by an in-process failover (no container restart) converges its managed
  users (POSTGRES_USER, REPMGR_USER) to scram. Still gated by
  `postgresql.migrateLegacyMd5Users` (default true); the password never appears on argv.

### Changed

- repmgr image -> `trixie-5.5.0-26` (`repmgr.image.tag` and the bundled
  `etcd.bootstrapImage.tag` default). The agent-mode `pg_hba.conf` now includes the md5
  compat lines it previously received from the postStart hook (byte-identical across
  primary and standby).

## 1.2.1 - 2026-06-22

Chart-only bug fixes from a full-chart review. No image change (`trixie-5.5.0-25`);
no rendered change at defaults.

### Fixed

- **NetworkPolicy never matched the metrics exporter.** The exporter NetworkPolicy and
  the postgresql ingress allow-from rule selected `app.kubernetes.io/component:
  prometheus-exporter`, but the exporter pods are labeled `postgres-exporter`. Under a
  default-deny CNI the policy attached to zero pods, so the exporter got no egress (DNS,
  5432) and was not admitted to PostgreSQL — metrics silently broke whenever
  `networkPolicy.enabled` and `prometheusExporter.enabled` were both true. The policy is
  now named `<fullname>-postgres-exporter` and selects the correct label.
- **`helm install/upgrade` failed under NetworkPolicy when the monitoring user was
  enabled.** The postgresql NetworkPolicy ingress did not admit the `monitoring-user`
  post-install/upgrade hook Job, so its connection to 5432 was dropped on a default-deny
  CNI and the hook failed the release. Added a `monitoring-user` ingress allow-from rule
  (gated on `prometheusExporter.monitoringUser.enabled`).

- **Bundled etcd RBAC-bootstrap Job image tag pinned in lockstep with the repmgr image.**
  The `etcd.bootstrapImage.tag` override is set to `trixie-5.5.0-25` in values so the
  bundled etcd's bootstrap Job no longer lags the pg-ha-agent image (the subchart default
  could skew).

### Added

- **`values.schema.json` enum guards** for `prometheusExporter.sslmode`,
  `pgpool.tls.backendSslmode`, `pgbackrest.s3.uriStyle`, and
  `pgbackrest.repoEncryption.cipherType` — a typo in these now fails install-time
  validation instead of misconfiguring the exporter/pgpool/backup at pod runtime.

### Changed

- **Agent ServiceMonitor selector scoped to the postgresql component.** It now matches
  only the headless Service (which carries `app.kubernetes.io/component: postgresql` and
  the agent-metrics port) instead of every Service in the release.
- **kube-linter probe waivers on one-shot Jobs/CronJobs.** The backup, backup-validation,
  pgbackrest, and monitoring-user Jobs/CronJobs now carry
  `ignore-check.kube-linter.io/no-{liveness,readiness}-probe` annotations, matching the
  policy gate's documented convention for one-shot workloads.
- **Tighter chart package.** `.helmignore` now excludes `tests/`, `Makefile`, and
  `kind-config.yaml` (and pgvector gained a `.helmignore`), so chart development
  scaffolding no longer ships inside the released `.tgz`.
- `int`-coerced `postgresql.replicaCount` in the service-updater ConfigMap script, for
  consistency with the rest of the chart.
- Clarified several values.yaml/template comments: plain-English wording for the
  "off by default" TLS notes, the `monitoringHistoryDays` repmgrd-mode scope (agent mode
  writes no monitoring_history), and the exporter scrape-role note.

## 1.2.0 - 2026-06-21

Optional client-connection TLS for PostgreSQL, PGPool, and the metrics exporter (#110),
plus optional cascading replication (#29). Both off by default — no rendered change at
defaults. Image moves to `trixie-5.5.0-25`.

### Added

- **Optional cascading replication (#29, `repmgr.agent.cascadingReplication`, agent mode,
  default off).** A standby may stream from another standby — a chain by pod ordinal toward
  the primary — to offload the primary's WAL senders on larger clusters (`replicaCount >= 2`).
  The agent only follows a verifiably-safe same-timeline upstream and stays sticky on it,
  re-homing to the leader on any upstream failure/promotion, so a standby is never stranded
  and failover is not delayed. Off by default the render and follow behavior are byte-stable.
- **PostgreSQL server TLS (`postgresql.tls.enabled`).** Serves `ssl = on` from a BYO
  Secret (`postgresql.tls.existingSecret`, keys `tls.crt`/`tls.key`/`ca.crt`, mounted
  read-only at `/etc/postgresql/tls`, `defaultMode: 0400`) via a chart-managed
  `tls.conf` injected over the `conf.d` include. Works in both agent and repmgrd mode and
  in standalone (`replicaCount: 0`) installs.
- **Enforced TLS (`postgresql.tls.require`) and mutual TLS
  (`postgresql.tls.clientCertAuth`), agent mode only.** `require` makes the pod-CIDR
  client rule `hostssl` (rejects non-TLS clients); `clientCertAuth` additionally requires
  a client cert (`clientcert=verify-ca`) for app users. The chart's internal service users
  (the `repmgr` user, the superuser, and the monitoring user) are **exempted** from the
  client-cert requirement so the agent prober, repmgr, the exporter, and PGPool keep
  working. Loopback and the `host replication` rule are never converted — **replication
  stays plaintext on the pod network** (a documented non-goal; repmgr/agent replication
  conninfo carries no `sslmode`).
- **PGPool TLS (`pgpool.tls.*`).** Frontend `ssl = on` (`existingSecret`, optional
  `clientCertAuth`), backend TLS to PostgreSQL via `backendSslmode`
  (`disable|prefer|require|verify-ca|verify-full`), and `backendClientCert` so PGPool can
  present a client cert to the backends under PostgreSQL mTLS.
- **Exporter `sslmode` (`prometheusExporter.sslmode`).** `disable|require|verify-ca|
  verify-full` for the metrics exporter's connection; `verify-*` mounts the CA from the
  server-cert Secret and sets `sslrootcert`.
- **Fail-fast guards.** Each `tls.enabled` requires its `existingSecret`;
  `require`/`clientCertAuth` require `tls.enabled` and agent mode; `require` requires the
  exporter and PGPool backend `sslmode >= require`; mTLS requires a CA and (with PGPool) a
  PGPool backend client cert; `verify-*` requires `postgresql.tls.enabled`.

### Fixed

- The outer `volumes:`/`annotations:` gates on the StatefulSet now include
  `postgresql.tls.enabled`, so a TLS-only install (no `postgresql.configuration`/
  `pgbackrest`) renders the cert volume (not just its mount) and the config checksum that
  rolls the pod when the cert/config changes.

### Notes

- repmgrd mode supports only **optional server TLS** (`ssl = on`); `require`/`clientCertAuth`
  are agent-mode only (repmgrd's md5-fallback `pg_hba` line would bypass a `hostssl` rule)
  and the render fails fast if requested there.
- PostgreSQL reloads `ssl_*` on SIGHUP, not when the mounted Secret changes — run
  `kubectl rollout restart` after rotating the cert Secret.

## 1.1.8 - 2026-06-21

Quiets the etcd RBAC health-probe noise (#187). Bundles `etcd` 0.1.5; image moves to
`trixie-5.5.0-24`. Only affects the opt-in shared-etcd TLS+RBAC path; no rendered change
at defaults.

### Fixed

- **etcd RBAC health probe no longer spams `cannot find a user for permission check`
  (#187).** With the bundled etcd's `tls.clientCertAuth` + `rbac.enabled`, the
  liveness/readiness probe presents the server cert, whose CN maps to no registered etcd
  user, so etcd logged this ERROR on every probe interval. (The probe still passed and
  quorum was still verified — `etcdctl endpoint health` treats permission-denied as
  healthy — so this was log noise, not a broken health check.) The `rbac-bootstrap` Job
  now provisions a dedicated **read-only health user** (read on the single `health` key
  the probe ranges), and the etcd server cert's CN is set to it
  (`etcd.rbac.healthCheckCN`, default `etcd-healthcheck`), so the probe authenticates
  cleanly and the log clears. The server cert CN is otherwise unused (clients verify by
  SAN), so this costs no new Secret. **Action for existing shared-etcd TLS+RBAC users:**
  reissue the etcd server cert with `CN=etcd-healthcheck` (see the etcd chart README).

## 1.1.7 - 2026-06-20

Fixes an agent-mode rolling-restart deadlock (#186). Image moves to
`trixie-5.5.0-23`. No rendered change in repmgrd mode; agent mode gains a
replication-aware standby readiness probe (below).

### Fixed

- **A rolling restart of a 2-node agent-mode cluster could deadlock with no writable
  primary (#186).** A within-1.x image bump triggers a StatefulSet `RollingUpdate`;
  two gaps combined to strand the cluster (data was safe, but writes stopped until
  manual intervention). Both are now fixed:
  - **Replication-aware standby readiness.** A standby reported `Ready` on bare
    `pg_isready` — before its clone/rejoin was durably streaming. Since `RollingUpdate`
    advances to the next pod only once the current one is Ready, this let the
    controller roll the primary / clone-source while a standby was still cloning,
    interrupting the clone. Agent-mode readiness is now role-aware: a primary stays
    `pg_isready`, but a standby is Ready only once its walreceiver reports
    `status='streaming'` (`pg_stat_wal_receiver`). The rolling update now serializes
    safely with no timing dependence. repmgrd-mode readiness is unchanged (byte-stable).
  - **Release the lease when the node cannot serve.** The `#170` PVC-loss guard
    correctly refuses to `initdb` an empty node, but the agent kept holding the
    leadership lease in that `Wait` state, blocking a data-bearing peer from promoting.
    An empty-data lease holder whose durable primary-marker names a *different* node now
    releases the lease so that recorded primary acquires and serves (the step-down
    cooldown lets it win before the empty node re-contends). A node whose own data was
    lost (the marker names itself) still settles as before. Downgrades any residual
    interruption from a manual-intervention deadlock to a few-second self-heal.
  - Covered by a new live `test-agent-rolling` suite (wired into CI) that rolling-restarts
    a 2-node agent cluster and asserts a single writable primary + re-streaming standby,
    no manual intervention.

## 1.1.6 - 2026-06-20

Restores efficient stale-primary recovery (#178) and automatically cleans up the
ghost `repmgr.nodes` rows a scale-down used to leave behind (#139). Image moves to
`trixie-5.5.0-22`; bundles `etcd` 0.1.4 (bootstrap-image tag lockstep only). No
rendered change in agent mode (the default); repmgrd mode gains the service-updater
cleanup described below.

### Fixed

- **Stale-primary recovery now rewinds with `pg_rewind` instead of always falling
  back to a full re-clone (#178).** The container-restart guard ran `repmgr node
  rejoin --force-rewind` with the repmgr password inlined in the `-d` connection
  string, but repmgr opens a *separate* replication connection to the rejoin target
  for the rewind and the inline password did not carry into it — so the rewind
  failed with "unable to establish a replication connection to the rejoin target
  node" and every stale-primary rejoin did an O(database-size) base backup. The
  guard now passes the credential via `PGPASSWORD` (as the clone path already did),
  so a diverged ex-primary rewinds forward onto the surviving primary's timeline.
  Data safety is unchanged (the re-clone fallback remains for genuine rewind
  failures); this only restores the efficient path on large databases. The live
  failover suite now asserts the rewind path engages.
  - Working rewind exposed a latent agent-failover bug it had been masking: the
    agent read a standby's timeline from the control file (`pg_control_checkpoint`),
    which only advances at a restartpoint, so a node that had followed a newly
    promoted primary onto a higher timeline by streaming — but not yet checkpointed
    — reported the old timeline and was wrongly rejected by the `#125` highwater guard
    on a subsequent failover (it could acquire the lease but refused to promote, so
    leadership never moved). The full re-clone used to hide this by copying the
    primary's control file at the new timeline. The agent now reads a standby's
    timeline as `GREATEST(checkpoint timeline, pg_control_recovery.min_recovery_end_timeline)`
    — the recovery-end timeline advances as the standby replays the timeline switch and
    persists in the control file after the upstream dies (the failover moment), so a
    streaming-caught-up standby reports its true timeline and promotes; data
    completeness remains the separate LSN/most-advanced-replica check.
- **Scaling `postgresql.replicaCount` down no longer leaves permanent ghost rows in
  `repmgr.nodes` (#139).** The StatefulSet trims the highest ordinals, but their
  `repmgr.nodes` records used to remain `active=true` forever — repmgrd kept retrying
  their now-dead conninfo, `repmgr cluster show` reported a permanently-failed node,
  and every failover paid a connect-timeout per ghost. The primary now reconciles
  `repmgr.nodes` against the live ordinal range on each tick and unregisters records
  for pods the StatefulSet no longer runs (agent mode: the lease-holding primary;
  repmgrd mode: the master's service-updater, which now mounts `repmgr.conf`). The
  discriminator is purely the ordinal (`node_id - 1000 > replicaCount`), never
  reachability, so a momentarily-down live node is never unregistered, and a
  scaled-down *primary* row is left for an operator (`repmgr standby unregister`
  refuses primary rows) rather than dropped. Covered by a new live `test-scaledown`
  suite (wired into CI). The manual `repmgr standby unregister` step previously
  documented for the 1.1.0 README is no longer required.
- **The repmgr image's two shell scripts now share the timeline helpers (#177).**
  `entrypoint.sh` and `init-repmgr.sh` had each carried their own copy of the timeline
  decode and reads; they now source a single `repmgr-common.sh` (`tl_to_int` + the
  WAL-insert and offline control-file reads), so a fix to the hex decode can't land in
  only some copies. `init-repmgr.sh` keeps its intentionally **symmetric** control-file
  timeline comparison (both the local node and the primary are read the same way), which
  avoids needlessly re-cloning a standby that has followed a new timeline by streaming
  but not yet checkpointed it.

## 1.1.5 - 2026-06-19

A monitoring-exporter `/probe` fix (#185). Chart-only; no image change (stays
`trixie-5.5.0-21`). The exporter ConfigMap changes when
`prometheusExporter.monitoringUser` is enabled (the default).

### Fixed

- **The least-privilege monitoring user (#28) broke the multi-target `/probe`
  scrape — every per-target `pg_up` was 0.** The exporter `auth_modules` DSN (used
  by `/probe`, unlike `DATA_SOURCE_NAME`) carried no database, so libpq defaulted
  `dbname` to the username `monitoring` and connected to a non-existent `monitoring`
  database (`pq: database "monitoring" does not exist`). It worked under the old
  superuser only because `dbname` then defaulted to the always-present `postgres`.
  The probe DSN now pins `dbname` to the configured database (substituted from
  `POSTGRES_DATABASE`, the same source as `DATA_SOURCE_NAME` and the only database
  the monitoring role is granted `CONNECT` on).

## 1.1.4 - 2026-06-19

Bundled-etcd security (#184). Bundles `etcd` 0.1.3; image moves to
`trixie-5.5.0-21` (adds the `pg-ha-agent rbac-bootstrap` subcommand). No rendered
behavior change at defaults.

### Added

- **Bundled etcd transport TLS (`etcd.tls.*`) and per-tenant RBAC (`etcd.rbac.*`),
  for the shared-etcd topology (#184).** etcd can now serve client + peer TLS from a
  BYO cert Secret with `--client-cert-auth` (mutual TLS), and a post-install/upgrade
  Job grants each tenant (matched by its client-cert Common Name) a role with
  `readwrite` only on its key prefix — so one release cannot read or rewrite another's
  leadership keys. A consuming release's agent authenticates by CN with no change (its
  existing etcd client mTLS); in bundled mode the parent auto-switches the endpoint to
  `https` and fails the render if the agent's client Secret is missing under
  client-cert-auth. The RBAC bootstrap runs via a new `pg-ha-agent rbac-bootstrap`
  subcommand (the bundled etcd image is distroless, so the Job uses the agent image +
  the Go etcd Auth API rather than a shell + etcdctl). All flag-gated
  (`etcd.tls.enabled`/`etcd.rbac.enabled` default off; render byte-stable). Covered by
  a new live KinD suite (`make -C pg test-agent-etcd-tls`, wired into CI) that proves
  the TLS handshake, CN auth, failover over mTLS, and that a tenant cert is denied
  outside its prefix.

## 1.1.3 - 2026-06-19

Multi-pillar-review remediation of the 1.1.2 etcd changes. Refreshes the bundled
`etcd` subchart to 0.1.2. Docs/test-quality only; no image change (stays
`trixie-5.5.0-20`) and no rendered behavior change at defaults.

### Fixed

- **Standalone-etcd guide pointed at a Service that never exists.** The etcd
  README's shared-store wiring used `http://<release>-etcd.<ns>` but the client
  Service renders as `<release>-etcd-etcd`; the install now sets
  `fullnameOverride` so the documented endpoint matches (#183 follow-up).
- **etcd `image.tag` pin comment was stale** (claimed it matched the agent's
  vendored client, which moved to v3.5.31); corrected to note the server is held
  at v3.5.16 and 3.5.x client/server are wire-compatible.

### Security

- **Hardened the `etcd.networkPolicy.allowedClients` guidance.** The default
  podSelector matches any `app.kubernetes.io/component: postgresql` pod in an
  allow-listed namespace, and the bundled etcd is plaintext/no-auth — documented
  this exposure in `values.yaml` and recommend an instance-pinned selector plus
  client TLS (#184).

### Changed

- Release landing page no longer advertises the `common` library chart as
  installable; `helm repo add` alias unified to `cagriekin` across the READMEs.
- Test coverage for `allowedClients` tightened: the default-podSelector assertion
  is now scoped (was doc-wide/tautological), and the custom-podSelector branch,
  multi-entry rendering, and the missing-namespace fail-fast message are asserted.

## 1.1.2 - 2026-06-19

Refreshes the bundled `etcd` subchart to 0.1.1. Chart-only; no image change
(stays `trixie-5.5.0-20`) and no behavior change at defaults -- a `helm upgrade`
rolls nothing unless `etcd.enabled` and the new value is set.

### Added

- **`etcd.networkPolicy.allowedClients` for the bundled etcd (#183).** The etcd
  NetworkPolicy only admitted this release's own postgresql pods on the client
  port, so a shared/standalone etcd had no first-class way to allow clients in
  other namespaces (only raw `extraIngress` with hand-written selectors). Added a
  declarative `allowedClients: [{namespace, podSelector?}]` knob that opens the
  client port (2379) per namespace; `podSelector` defaults to the agent's
  `app.kubernetes.io/component: postgresql` label. Default `[]` (render
  byte-stable). The `etcd` chart is now also published standalone (0.1.1) so
  several `pg` releases can share one etcd; see its README.

## 1.1.1 - 2026-06-19

Security: bump the HA agent's vendored Go dependencies off two CVE-flagged
versions. Image moves to `trixie-5.5.0-20`. No chart-template or values changes
beyond the image tag; a `helm upgrade` rolls the pods once.

### Security

- **Bumped `google.golang.org/grpc` 1.59.0 -> 1.79.3 (CVE-2026-33186, critical)
  and `golang.org/x/oauth2` 0.21.0 -> 0.34.0 (CVE-2025-22868, high)** in the
  `pg-ha-agent` module. Both were transitive (grpc via `go.etcd.io/etcd/client/v3`,
  oauth2 via `k8s.io/client-go`); the etcd client is bumped 3.5.16 -> 3.5.31 within
  the stable 3.5 line so the grpc jump stays source-compatible, and oauth2 floats to
  3.5.31/grpc's required 0.34.0 (>= the 0.27.0 fix). `govulncheck` reported both as
  unreachable (no vulnerable symbol is called from the agent), so there was no
  exploit path in the running binary -- the bump clears the advisories and keeps the
  supply chain current. Re-vendored; hermetic build, `go mod verify`, `go vet`, unit
  tests, and `govulncheck` (now zero) all pass.

## 1.1.0 - 2026-06-19

### Added

- **WAL-archiving health metrics for the Prometheus exporter (#30).** When
  pgBackRest is enabled the exporter now serves a `pg_wal_archive` query group from
  `pg_stat_archiver` (scraped on the primary): `pg_wal_archive_failed_count`
  (archive_command failures), `pg_wal_archive_archived_count`,
  `pg_wal_archive_seconds_since_last_archived`, and
  `pg_wal_archive_seconds_since_last_failed`. Previously a stalled `archive_command`
  surfaced no metric and fired no alert. The query reads only `pg_stat_archiver`, so
  it needs no filesystem/superuser access (compatible with a future read-only
  monitoring user, #28).
- **Opt-in automated backup-validation CronJob (#31).** A new weekly CronJob
  (`backup.validation.enabled`, default off) downloads the latest `pg_dump` backup
  and restores it into a throwaway PostgreSQL inside the Job pod -- never the live
  database -- failing the Job (so it alerts) if `pg_restore --exit-on-error` trips (a
  restored database with no table-like relations is only a warning, since a
  schema/extension-only database restores cleanly). Nothing previously verified that backups were
  actually restorable beyond a TOC `pg_restore --list` check. Configurable
  `schedule`, `resources`, and `workdirSizeLimit` (the throwaway PGDATA emptyDir
  cap, default unbounded). It reuses the postgresql securityContext (runs
  initdb/postgres as the postgres uid) and the release-scoped S3 path.

### Security

- **The Prometheus exporter connects as a least-privilege `pg_monitor` user, not the
  postgres superuser (#28).** A post-install/post-upgrade hook Job creates a read-only
  monitoring role on the primary (it replicates to standbys) and the exporter
  authenticates as it. Chart-only -- works in both repmgr and standalone modes with no
  image change. Enabled by default (`prometheusExporter.monitoringUser.enabled`);
  disable to revert to the superuser. **Migration (existingSecret users):** because
  this is on by default, before upgrading add a `monitoring-password` key to your
  existing secret (key name overridable via
  `postgresql.existingSecret.monitoringPasswordKey`), or set
  `prometheusExporter.monitoringUser.enabled=false`. The chart references that key name
  (validated at render); a key missing from the secret itself surfaces at runtime as
  the exporter + hook Job failing to authenticate, not as a render error.
- **The backup and backup-validation Jobs run under a dedicated ServiceAccount, not
  the namespace default (#27).** A new no-RBAC `<fullname>-backup` ServiceAccount
  (its token is never mounted, #166) backs both Jobs, which talk only to PostgreSQL
  and S3. Previously they ran as the namespace default SA.
- **pgBackRest repository encryption is now an option (#120).** `repo1-cipher-type`
  was hardcoded to `none`. Set `pgbackrest.repoEncryption.enabled=true` (cipher
  `aes-256-cbc` by default) to encrypt the repository at rest in S3; the passphrase is
  read from `pgbackrest.repoEncryption.existingSecret` and supplied to pgbackrest via
  the `PGBACKREST_REPO1_CIPHER_PASS` env (postgresql container + sidecar), never
  written into the ConfigMap. Default stays unencrypted. A PITR restore pod must set
  the same env when restoring an encrypted repository.
- **All container images are digest-pinnable (#26).** Every image -- postgres, repmgr,
  pgpool, pgpool-exporter, prometheus-exporter, busybox, `mc`, and the pgBackRest
  CronJob runner -- now takes an optional `image.digest` (the repmgr image already
  did). When set it renders `repository:tag@digest`, so a mutable-tag repush cannot
  silently change the deployed image. Empty by default (pull by tag; render is
  byte-stable). Routed through a shared `pg.image` template helper.
- **`readOnlyRootFilesystem` on the auxiliary containers (#117).** The Prometheus
  exporter, the backup and backup-validation Jobs, and the pgBackRest CronJob runner
  now run with a read-only root filesystem, each paired with a writable `/tmp`
  emptyDir (and `HOME=/tmp` for the runner's kubectl cache). The service-updater and
  the pgpool metrics exporter share the postgresql/pgpool securityContext (whose main
  containers need a writable root), so hardening those needs a dedicated context --
  left as a follow-up.
- **The PgPool-II PCP admin port (9898) is no longer exposed on the Service by default
  (#118).** The pgpool Service published the PCP admin/control port cluster-wide, while
  the pgpool NetworkPolicy only admits 9999 — so with NetworkPolicy off the admin
  endpoint was reachable by any pod, and with it on the Service port was dead. It is now
  gated behind `pgpool.service.exposePcp` (default `false`). Enable it only if you run
  `pcp_*` commands against the Service, and pair it with a `pgpool.extraIngress` rule for
  9898 when NetworkPolicy is enabled.
- **The `fix-permissions` init container drops its excess capabilities (#162).** The
  chown init container legitimately needs root, but it inherited the runtime's full
  default capability set (SETUID, SETGID, NET_RAW, …). It now drops ALL and adds back
  only `CHOWN`, `DAC_OVERRIDE`, `FOWNER` (what `chown -R` / `chmod` need), matching the
  tighter pattern the chart's other root init container already uses.
- **The pgBackRest backup CronJob is now security-hardened (#155).** It was the one
  pod with zero hardening — running as the image default (root), full capability set,
  no seccomp profile, `allowPrivilegeEscalation` unset — yet it carries the
  exec-capable pgBackRest ServiceAccount token, and it failed admission in
  Pod-Security-`restricted` namespaces while the rest of the release deployed. It now
  applies `pgbackrest.cronjob.podSecurityContext` / `containerSecurityContext`
  (defaults: `runAsNonRoot`, `runAsUser: 65534`, `seccompProfile: RuntimeDefault`,
  `allowPrivilegeEscalation: false`, drop ALL capabilities), matching the chart's other
  pods. `alpine/k8s` runs `kubectl` fine as a non-root uid.
- **Pods that make no Kubernetes API calls no longer mount a ServiceAccount token
  (#166).** The pgpool Deployment, the prometheus-exporter Deployment, the backup
  CronJob, and the StatefulSet in standalone (`repmgr.enabled=false`) mode ran as the
  namespace default ServiceAccount with its token projected in — an unnecessary,
  valid API credential in pods that also hold the postgres superuser password. They
  now set `automountServiceAccountToken: false`. The repmgr StatefulSet keeps its
  token (the agent / service-updater genuinely call the API).
- **S3 credentials no longer passed on the `mc` command line (#167).** The backup
  job ran `mc alias set s3 <endpoint> <access-key> <secret-key>`, exposing both keys
  in the process argv (`/proc/<pid>/cmdline`, readable via `ps` by other users on the
  node, hostPID pods, and command-line-logging agents) on every scheduled run.
  Credentials are now supplied to `mc` via the `MC_HOST_s3` environment variable
  (percent-encoded so reserved characters in real keys survive), so they never appear
  in argv. Requires `backup.s3.endpoint` to include a scheme (`http://`/`https://`),
  which `mc` already required.

### Documentation

- **Corrected the false "clean deregistration" claim and documented scale-down ghost
  nodes (#139).** The README claimed the repmgrd preStop hook (`repmgr daemon stop`)
  performed "clean deregistration" — it does not; it only stops the daemon. Scaling
  `postgresql.replicaCount` down therefore leaves the removed nodes in `repmgr.nodes`
  as `active` ghosts (`repmgr cluster show` shows them failed; in repmgrd mode the
  survivors keep retrying the gone DNS names, adding failover-election delay). The
  README now describes the preStop hook accurately and adds a **Scaling down** section
  with the manual `repmgr standby unregister --node-id=<ordinal+1000>` cleanup.
  (Automatic deregistration is not yet implemented — tracked in #139.)
- **Clarified that `networkPolicy.postgresql.allowExternal=false` blocks the read-only
  Service (#148).** `allowExternal` gates direct client access to PostgreSQL on 5432,
  which is exactly the path the `<fullname>-readonly` Service (direct standby reads)
  uses — so with `allowExternal: false` those read connections silently time out while
  `kubectl get endpoints` looks healthy (PGPool on 9999 stays reachable, so read-write
  clients via PGPool are unaffected). Documented the interaction in the README and
  `values.yaml`, with a scoped `extraIngress` recipe to re-allow direct-5432 clients. No
  default behavior change.
- **The pgBackRest PITR restore runbook could not work as written (#149).** The
  documented restore pod mounted only the data PVC and set the S3 key env vars, but
  not the `<fullname>-pgbackrest` ConfigMap — which is the only place `pg1-path` and
  the `repo1-*` S3 settings live. `pgbackrest restore` therefore failed with
  `requires option: pg1-path` (and, once that was worked around, defaulted to a local
  posix repo, never finding the S3 backup). The runbook now mounts the ConfigMap at
  `/etc/pgbackrest/pgbackrest.conf`, sources the keys from the existing pgBackRest
  secret, sets the chart's `securityContext` (101:103) so restored files are owned
  correctly and the pod passes restricted PodSecurity/OpenShift, adds the required
  `--type=time` to the `restore --target` command, corrects the `keyType: auto`
  guidance (bind the restore pod to the `<fullname>-repmgr` SA, not the default), and
  uses the current image tag.
- **Corrected the pgBackRest troubleshooting pointer (#151).** The troubleshooting table
  told operators to check `pgbackrest-scheduler` logs — a container that does not exist
  (backups migrated from an in-pod scheduler sidecar to CronJobs). It now points at the
  `pgbackrest` sidecar on the primary and the `<fullname>-pgbackrest-full`/`-diff` CronJob
  pod logs.
- **Synced the documented `repmgr.image.tag` default with `values.yaml`.** The parameter
  table listed `trixie-5.5.0-16`; the chart ships `trixie-5.5.0-18`.

### Fixed

- **repmgr SCRAM startup deadlock eliminated (image `trixie-5.5.0-19`).** `initdb
  --auth-host=md5` makes the image write `password_encryption=md5`, so the bootstrap
  created the `repmgr`/`postgres` users with MD5 secrets -- but `pg_hba.conf` requires
  `scram-sha-256` for the `10.0.0.0/8` pod network. When a standby's `repmgr-init`
  clone or `repmgrd` connected over that network before the chart's postStart
  md5->scram migration had run, PostgreSQL rejected it with "does not have a valid
  SCRAM secret", crash-looping repmgrd / wedging the standby clone until
  `helm install --wait` timed out -- an intermittent CI/install failure. The image now
  creates the managed users with a SCRAM secret directly (the same end state the
  migration drives them to), so replication auth works from first boot regardless of
  migration timing. The global default stays `md5` for legacy/app users; the migration
  and the md5-above-scram `pg_hba` patch remain as a safety net.
- **Helper init images are now a single configurable value (#116).** The four
  busybox init containers (the StatefulSet `fix-permissions`/`setup-config`, and the
  pgpool and exporter config inits) hardcoded the busybox image -- inconsistently
  (`1.35` vs `1.37`) and with no override, blocking air-gapped/private-registry
  deployments. They now share a `busyboxImage` value (`repository`/`tag`/`pullPolicy`,
  default `busybox:1.37`). The pgBackRest CronJob (`pgbackrest.cronjob.image`) and the
  backup `mc` image (`backup.mc.image`) were already configurable.
- **Primary lookup uses EndpointSlice instead of the deprecated Endpoints API
  (#121).** The pgBackRest backup CronJob resolved the current primary with
  `kubectl get endpoints`; the core Endpoints API is deprecated in favor of
  EndpointSlice. The CronJob now lists the write Service's EndpointSlices
  (`discovery.k8s.io`, filtered to the Ready endpoint) and the Role grants
  `endpointslices` instead of `endpoints`. EndpointSlice names are auto-generated,
  so this is a namespace-scoped read of EndpointSlice metadata (list) rather than a
  resourceName-scoped get; the security-critical pods/exec scoping (#134) is
  unchanged.
- **Removed the dead `REPMGR_NODE_COUNT` env from the service-updater container
  (#177).** The service-updater script derives its peer-scan range from
  `replicaCount` at template time and never read the env, so it was dead config on
  that container. It stays on the `repmgr-init`/`postgresql`/`repmgrd` containers,
  which the image scripts do consume. (The image-side de-duplication of the
  triplicated peer-scan/timeline logic noted in #177 is a separate follow-up.)
- **Backup integrity check no longer buffers the whole dump to `/tmp` (#119).** The
  verify step did `mc cat > /tmp/verify_backup.dump` before `pg_restore --list`, writing
  the entire dump to the container's unbounded, unsized writable layer — a large
  database could hit node-disk eviction. It now streams the archive
  (`mc cat … | pg_restore --list`), so the TOC is checked without staging the dump
  locally.
- **Init containers now declare resource requests/limits (#153).** No init container
  set resources, so in a namespace with a `ResourceQuota` requiring requests/limits
  every pod of the chart was rejected at admission (Forbidden) unless a `LimitRange`
  happened to inject defaults — and the `repmgr-init` standby clone (a full
  `pg_basebackup`) ran with unbounded CPU/memory/IO. The lightweight inits (chown, cp,
  config-gen across the StatefulSet, pgpool/exporter Deployments, and backup CronJob)
  now use a small shared default; `repmgr-init` uses an overridable
  `repmgr.initContainerResources` (heavier, sized for the clone).
- **emptyDir volumes are now size-capped (#165).** None of the chart's emptyDirs set a
  `sizeLimit`, so a runaway volume — especially PGDATA when `persistence.enabled=false`
  — could fill the node's root filesystem and evict unrelated pods instead of being
  capped and evicted itself. Fixed caps are set on the config/tool/extension volumes
  (16Mi config, 128Mi backup tools, 1Gi extension trees), and the non-persistent data
  volume gets a configurable `postgresql.persistence.emptyDir.sizeLimit` (default empty
  = unbounded, preserving prior behavior; set e.g. `8Gi` for ephemeral use).
- **pgBackRest `stanza-create` no longer masks real failures (#160).** The pgBackRest
  backup CronJob ran `stanza-create || true`, which swallowed not just the benign
  "stanza already exists" case (`stanza-create` is natively idempotent and exits 0 then)
  but also genuine failures — S3 permission errors, a repo lock, a `kubectl exec`
  transport error, or a needed `stanza-upgrade` after a PG major upgrade — so the job
  proceeded to the backup step and failed there with a misleading downstream error
  instead of the root cause. Dropped `|| true`; under `set -eu -o pipefail` a real
  `stanza-create` failure now aborts the job at the right step with the actual message.
- **The postgres-exporter NetworkPolicy now has a cross-namespace scrape escape hatch
  (#147).** The exporter's 9116 metrics ingress admitted same-namespace pods only
  (`podSelector: {}`), and — unlike the postgresql/pgpool policies — had no `extraIngress`
  value, so a Prometheus in a separate monitoring namespace (the usual `ServiceMonitor`
  topology the chart ships) could not scrape it and there was no chart-supported fix
  short of disabling NetworkPolicy. Added `networkPolicy.prometheusExporter.extraIngress`
  / `extraEgress` (mirroring postgresql/pgpool) so a `namespaceSelector` rule can allow
  the scraper; documented the cross-namespace limitation (exporter 9116, pgpool 9719,
  agent 9200) in the README. No default behavior change.
- **postgres-exporter probes now detect a broken scrape pipeline (#146).** Both probes
  hit the landing page `/`, which returns 200 unconditionally — so a `queries.yaml` /
  collector regression that makes every scrape fail with HTTP 500 (as the chart's own
  0.5.73–0.5.81 regression did for nine releases) left the exporter pods Ready and never
  restarted while all DB metrics went dark. The liveness and readiness probes now hit
  `/metrics` (matching the pgpool exporter), which returns 500 on genuine exporter/
  registry breakage but 200 + `pg_up 0` on a database outage — so the probe catches
  config breakage without flapping when the DB is merely down.
- **pgpool PDB no longer wedges node drains on a single-replica install (#161).** The
  pgpool PodDisruptionBudget used `minAvailable: 1` with the default `pgpool.replicaCount:
  1`, so allowed disruptions were permanently 0 — `kubectl drain`, managed node upgrades,
  and autoscaler scale-down hung indefinitely on the pgpool node. It now uses
  `maxUnavailable: 1` + `unhealthyPodEvictionPolicy: AlwaysAllow` (mirroring the
  postgresql PDB): a single-replica pgpool can be evicted (it is stateless and simply
  reschedules), while a multi-replica pgpool keeps rolling protection (at most one pod
  down at a time). The shared `common.podDisruptionBudget` helper now renders exactly
  one of `minAvailable`/`maxUnavailable` (an explicit `minAvailable` wins, else
  `maxUnavailable`), so a partial override can no longer emit both — which the API
  rejects.
- **Numeric/boolean-looking env values no longer fail at apply (#156).** Several
  container env values (`REPMGR_USER`, `REPMGR_DB`, `PGBACKREST_STANZA`, `STANZA`,
  `SPLIT_BRAIN_ACTION`, the Service/marker/Lease names, FQDNs) were interpolated into
  `value:` without `| quote`. A value that YAML types as a number or bool (e.g.
  `repmgr.database=12345`, `pgbackrest.stanza=123`) rendered as a bare scalar that the
  API server rejects (`cannot unmarshal number into field of type string`) — passing
  `helm template`/`lint` but failing at apply. All
  user-facing env values are now `| quote`d (composite names via `printf … | quote`),
  matching the already-quoted `MONITORING_HISTORY_DAYS`/S3 envs.
- **Single quotes in `postgresql.configuration` / `pgpool.resetQueryList` no longer
  produce an invalid config (#157).** Both were interpolated naively into single-quoted
  conf lines, so a value containing a `'` (e.g. in `log_line_prefix` or
  `archive_command`) rendered a syntactically-invalid `custom.conf` — putting the
  postgres pods into CrashLoopBackOff after the config-checksum roll — or a broken
  `reset_query_list` that stopped pgpool from starting. Embedded single quotes are now
  doubled (`''`, the PostgreSQL/pgpool conf-lexer escape) in `postgresql.configuration`
  values, `pgpool.resetQueryList`, and the `archive_command` stanza. Values without
  quotes render unchanged. (Newline-bearing conf values remain unsupported — they fail
  the render rather than injecting a directive.)
- **Long release/fullname now fails fast instead of rendering invalid resource names
  (#158).** `pg.fullname` is capped at 63 but per-resource suffixes are appended after
  it, so a long `fullnameOverride` could render a Service name over 63 chars (rejected
  by the API server) or a CronJob name over ~52 chars (silently fails to spawn Jobs) —
  with no render-time hint. The chart now validates composed Service (≤63),
  Deployment-backed (≤47, for pgpool/exporter Pod names) and CronJob (≤52) names at
  render time and fails with a clear message naming the offending name and the current
  `pg.fullname` length. Truncation was rejected as unsafe on a stateful
  chart (two long names could collide on one StatefulSet/PVC). Normal names are
  unaffected (the guard is a no-op).
- **A failed `pg_dump` left a truncated dump masquerading as the newest backup
  (#159).** If `pg_dump` exited non-zero mid-stream (connection drop during failover,
  OOM), `mc pipe` finalized the truncated object at the canonical
  `backup_<ts>.dump` name and it remained the lexically-newest backup until the next
  successful run (~24h) — so an operator restoring "the latest" during an incident
  could pick a corrupt dump. The dump is now streamed to a `.tmp` staging object and
  published to the canonical name with `mc mv` only after the `pg_restore --list`
  integrity check passes, so a truncated dump never reaches the canonical name. An
  EXIT trap removes the staging object on failure, and retention also sweeps stale
  `.tmp` objects orphaned by a hard-killed run.
- **pgBackRest config changes (S3 endpoint/bucket/retention) didn't roll the pods
  (#145).** `pgbackrest.conf` is a subPath mount — which the kubelet never
  live-updates — and the StatefulSet pod template did not checksum the pgBackRest
  ConfigMap (only `postgresql-configmap`). So after a `helm upgrade` that repointed
  the repository, every running pod's `archive_command` and the pgbackrest sidecar
  kept writing to the OLD location until manually restarted — backups looked green
  while landing in the wrong place, discovered only at restore time. The pod template
  now carries a `checksum/pgbackrest-config` annotation, so any pgBackRest config
  change rolls the StatefulSet (one pod at a time) and the new config takes effect.
  Operator note: changing `pgbackrest.s3.*`/`pgbackrest.retention.*` now restarts the
  pods (previously a no-op); rolling the current primary triggers a controlled
  failover, the same as any rolling upgrade.
- **Backup retention could delete another release's dumps under a shared
  bucket/prefix (#143).** `pg_dump` backups were written to a flat
  `<bucket>/<prefix>/backup_<ts>.dump` with no release identity, and the retention
  `mc find ... --older-than --exec mc rm` ran recursively over the whole prefix with
  no name filter — so two releases (e.g. staging + prod) sharing one bucket/prefix
  each deleted the other's dumps older than their own `retentionDays`. Dumps are now
  namespaced per release under `<prefix>/<release-fullname>/` (mirroring the
  pgBackRest repo layout), and both the recent-backup guard and the retention delete
  are scoped to that subpath with a `--name 'backup_*.dump'` filter (so unrelated
  objects under the prefix are never touched either). Existing dumps under the old
  flat path are left in place (not migrated, not deleted); see the README restore
  section for the new path layout.

## 1.0.2

Bugfix for agent mode (the 1.0.0 default). Image moves to `trixie-5.5.0-18`. No
chart-template or values changes beyond the image tag; a `helm upgrade` rolls the
pods once.

### Fixed

- **Agent re-ran `repmgr standby follow` every reconcile tick on a healthy,
  already-streaming standby and logged an ERROR each time (#182).** The `Follow`
  executor latched its idempotency guard (`followUpstream`) only after
  `repmgr standby follow` returned success. On a standby that was already correctly
  streaming from the lease holder -- which is the steady state right after a
  repmgrd->agent migration (`primary_conninfo` persists across the roll) or a
  post-failover rejoin -- the command exits non-zero (`slot "..." already exists as
  an active slot` / `this server is not ahead`), so the guard never latched and the
  agent re-forked the failing command every ~5s. Replication was unaffected, but the
  ERROR spam (~1 every tick per standby) buried genuine errors and tripped log-based
  alerting. The agent now (1) skips `repmgr standby follow` entirely when it observes
  via `pg_stat_wal_receiver` that the standby is already streaming from the target,
  and (2) treats the benign "already following" repmgr exit as a successful no-op, so
  the guard latches and the command is not re-run. Repointing to a genuinely new
  upstream (after a leader change) still runs `follow`. Regression coverage: pg
  probe, mechanism, and act-path unit tests.

## 1.0.1

Bugfix for agent mode (the 1.0.0 default). Image moves to `trixie-5.5.0-17`.

### Fixed

- **Agent standby never re-established streaming after a failover / repmgrd->agent
  migration (#181).** The agent decided "running vs stopped" purely from SQL
  reachability and, when SQL was unreachable, read the role from `pg_controldata`.
  A freshly-cloned standby still rejecting connections (`the database system is
  starting up`) was therefore misclassified: right after `pg_basebackup` the control
  file still carries the source primary's `in production` state, so the agent saw a
  "stopped primary" and issued `RejoinForward`, which terminated the standby's
  walreceiver mid-stream; it then looped `StartLocal` on the recovering node. The
  standby never reached consistency and the cluster was left single-node.
  The agent now tracks **process liveness** (`Supervisor.Running()`) separately from
  SQL readiness: while its own postmaster is alive but not yet accepting connections
  (and not self-health-stuck), it **waits** for the node to reach a ready state
  instead of acting on the transient on-disk role. Self-health failover of a
  genuinely frozen primary is unaffected. Regression coverage: reconcile
  decision-table cases, plus `test-agent-failover` / `test-migrate-agent` now assert
  the rejoined standby is actively streaming (`pg_stat_replication`).

First major release. The lease-based Go agent (`pg-ha-agent`) is now the
**default** failover mode, and the `pg` and `pgvector` charts move to a single,
aligned 1.0.0 version line. The repmgr image is `trixie-5.5.0-16`, which bundles
the agent binary.

### BREAKING

- **`repmgr.failoverMode` defaults to `agent`** (was `repmgrd`). New installs run
  the lease-based agent. The legacy repmgrd + service-updater path remains
  available for one major cycle via `repmgr.failoverMode: repmgrd` (deprecated).
- Agent mode uses `podManagementPolicy: Parallel` (repmgrd uses `OrderedReady`),
  an **immutable** StatefulSet field, so switching an existing repmgrd release to
  agent mode requires a one-time `--cascade=orphan` StatefulSet recreate.
- Agent mode assembles a hardened `pg_hba.conf` (pod-CIDR + SCRAM, no implicit
  `0.0.0.0/0 md5`). Consumers who relied on the broad md5 rule must add explicit
  `postgresql.pgHba` rules before switching.
- The postgresql PodDisruptionBudget default is `maxUnavailable: 1` +
  `unhealthyPodEvictionPolicy: AlwaysAllow` (was `minAvailable: 1`); equivalent on
  a 2-pod cluster, strictly better for drains/upgrades (k8s >= 1.27).

### Migrating to 1.0.0

- **Stay on repmgrd (no behavior change):** set `repmgr.failoverMode: repmgrd` and
  `helm upgrade`. Pods roll once for image `trixie-5.5.0-16`; nothing else changes.
- **Adopt agent mode (default):** with a fresh backup and a healthy cluster, and
  ArgoCD auto-sync paused if used:
  1. `kubectl delete statefulset <release>-pg --cascade=orphan -n <ns>` (keeps pods
     + PVCs running; Helm re-adopts them).
  2. `helm upgrade <release> ... ` (recreates the StatefulSet as `Parallel`, adopts
     the orphaned pods, rolls them into agent mode). The migration guard stops a
     first-rolled standby from becoming a second writer.
  3. Verify: `kubectl get lease <release>-pg-leader` holder == the primary;
     `kubectl get endpoints <release>-pg` points at it; write a row; in staging
     trigger a failover and confirm the Lease moves and data survives.
  - Rollback is symmetric (flip back to `repmgrd` with the same `--cascade=orphan`
    recreate, then optionally `kubectl delete lease <release>-pg-leader`).
  - Full runbook (GitOps caveats, DR/PITR, pg_upgrade, the etcd DCS backend) is in
    the README.

The sections below describe the agent machinery introduced across the 0.5.x line
and now shipping as the 1.0.0 default; the repmgrd rendering is byte-stable.

### Added

- `repmgr.failoverMode: agent` runs a Go agent (`pg-ha-agent`) as PID 1 in the
  postgresql container. The agent holds a Kubernetes `coordination.k8s.io/v1`
  Lease (`<release>-pg-leader`) as the sole authority for which node is primary
  and drives repmgr as a pure mechanism (no repmgrd). This removes the
  hand-rolled split-brain handling and the repmgrd startup race at the source.
- Agent-mode wiring (gated, repmgrd path unchanged): `podManagementPolicy:
  Parallel`, the entrypoint `agent` arm, agent env (`LEASE_NAME`,
  `LEASE_DURATION`, `RENEW_DEADLINE`, `RETRY_PERIOD`, `RECONCILE_INTERVAL`,
  `POD_NAME`, `MASTER_SERVICE`, `POD_SELECTOR`, `DCS_BACKEND`,
  `SPLIT_BRAIN_ACTION`), a `9200` metrics/health port with an agent-heartbeat
  liveness probe, `coordination.k8s.io/leases` RBAC scoped to the leader Lease,
  pgpool backends fronting the RW/RO Services, and a `9200` NetworkPolicy
  ingress. The repmgrd sidecar, service-updater sidecar, and the service-updater
  ConfigMap are omitted in agent mode.
- `repmgr.agent.*` tunables (`leaseDuration`, `renewDeadline`, `retryPeriod`,
  `reconcileInterval`, `podCidr`).
- Agent operability: **cluster-identity safety** — a clone/follow/rewind from a
  peer of a different cluster is refused by comparing the PostgreSQL
  `system_identifier` (guards against a stale/misrouted/DR-restored peer);
  **maintenance mode** — `kubectl annotate configmap <release>-pg-primary
  pg-ha/pause=true` suspends automatic promote/demote/fence/self-health while the
  agent keeps serving; **controlled switchover** — `pg-ha/switchover-target=<pod>`
  hands the primary role to a caught-up, same-timeline standby; and on-DCS data
  (the marker + gossip) carries a `schemaVersion` so a mixed-version rolling agent
  upgrade is safe.
- Agent monitoring (opt-in, agent mode): `repmgr.agent.monitoring.serviceMonitor`
  and `repmgr.agent.monitoring.prometheusRule` ship a ServiceMonitor (scraping the
  agent's read-only metrics on `9200`) and example alert rules — no-leader,
  multiple-leaders (split-brain), agent-down, lease-renew-failing,
  reconcile-errors, flapping, and paused-too-long. Replication-lag alerting stays
  with the PostgreSQL exporter.
- etcd leadership backend (opt-in, agent mode): `repmgr.agent.dcs.backend: etcd`
  holds the leader lock in etcd instead of a Kubernetes Lease, so a control-plane
  outage no longer self-demotes the primary (only an etcd quorum loss does).
  Provide a **BYO/shared** etcd via `repmgr.agent.dcs.etcd.endpoints` (+ optional
  mutual TLS via `dcs.etcd.tls.secretName`), or set `etcd.enabled=true` to deploy a
  **bundled** 3-node etcd subchart that the agent auto-targets. In etcd mode the
  `coordination.k8s.io/leases` RBAC grant is dropped and egress to etcd `:2379` is
  opened. Default stays `kubernetes`.

### Notes

- Agent mode is opt-in and stays off by default — repmgrd installs are unchanged
  and need no action. It becomes the default at chart `1.0.0`. Graceful failover
  in agent mode is covered by the live KinD suite (`make -C pg test-agent`).
- **Migrating to agent mode:** `podManagementPolicy` is immutable, so switching an
  existing release needs a one-time `kubectl delete statefulset <release>-pg
  --cascade=orphan` (keeps pods + PVCs) then `helm upgrade --set
  repmgr.failoverMode=agent`. Full runbook + GitOps caveats in the README
  ("Failover modes" / "Migrating an existing release to agent mode"); injected env
  is catalogued in `ENVIRONMENT.md`.
- The new PostgreSQL settings (`wal_log_hints`, `max_replication_slots`,
  `max_slot_wal_keep_size`, `restore_command`) are applied at `initdb`, so they
  take effect on freshly-provisioned clusters only. An existing cluster keeps its
  current settings on upgrade; to get `wal_log_hints=on` (so `pg_rewind` works
  without data checksums) and the bounded slot cap, set them via
  `postgresql.configuration` or apply them manually and restart.

## 0.5.88

Bundles the stale-primary/HA hardening, operational fixes, fail-fast
validation, and RBAC scoping accumulated since 0.5.87. The repmgr image is
now `trixie-5.5.0-15`.

### Fixed

- WAL-filename timeline is decoded as hexadecimal, not a decimal `::int`
  cast that errored at timeline `0x0A` and was wrong from `0x10` — this had
  silently broken the whole stale-primary family past ~10 failovers (#168).
- Split-brain handling in the default `log` mode re-asserts the write
  selector toward the highest-timeline primary every tick, restoring the
  ArgoCD self-heal during a split-brain window (#169).
- A failed `pg_rewind` rejoin preserves the diverged data (moved aside)
  before re-cloning, instead of wiping PGDATA ahead of the clone (#175).
- The empty-data stale-primary guard only settles/retries the peer scan on a
  PVC-loss recreate (gated on the durable primary marker), adding no latency
  on a genuine first install; the settle breaks only on a confirmed active
  primary and the marker lookup is time-bounded (#170).
- The lone-primary marker guard fails closed: an equal-timeline different-node
  split-brain is refused rather than overwriting the marker (#171); an
  unreadable timeline holds the current selector even before the marker
  exists (#173); a corrupt non-numeric marker timeline is treated as an error,
  not as "no marker" (#174).
- Readonly-Service pods are labeled `pg-role=standby` only when actually in
  recovery; a reachable non-master that is not in recovery (a stale/divergent
  primary) is labeled `orphan` and kept out of read traffic (#140).
- `postStart` `additionalCommands` reach the discovered primary in repmgr mode
  (`PGPASSWORD` exported for the cross-pod connection; `PGHOST` exported as its
  own statement), fixing automatic extension creation / DDL that was a silent
  no-op (#127).
- Disabling pgbackrest after install neutralizes the persisted `archive_mode` /
  `archive_command`, preventing a permanently failing `archive_command` from
  blocking WAL recycling and filling the data PVC (#132).
- The service-updater seeds `LAST_MASTER` from the live write-Service selector,
  so it no longer rollout-restarts PGPool (severing pooled connections) on
  every install/upgrade/sidecar restart with no actual failover (#138).
- repmgr-mode `postgresql.pgHba` entries are inserted above the image's network
  catch-all rules (first-match-wins), not appended at EOF where they were
  unreachable (#144).
- The PGPool NetworkPolicy opens the metrics scrape port 9719 when
  `pgpool.metrics.enabled`, and `networkPolicy.*.extraIngress` entries are full
  ingress rules so they can open ports other than 5432 (#135, #136).
- `postgresql` egress to PGPool's backend port 9999 is allowed so the
  service-updater health check no longer perpetually rollout-restarts PGPool
  (#129).

### Added

- A `startupProbe` on the PostgreSQL container suspends liveness/readiness until
  PostgreSQL first accepts connections, so the stale-primary guard settle and
  crash-recovery WAL replay cannot be killed mid-startup into a CrashLoopBackOff
  (`postgresql.startupProbe.*`, #172, #141).
- `repmgr.image.majorVersion` declares the PostgreSQL major bundled in the
  repmgr image; a `postgresql.majorVersion` mismatch now fails at render in
  repmgr mode rather than crash-looping or silently running the wrong major
  (#133).

### Security

- The repmgr Role's `pods` `get`/`patch` are scoped to the StatefulSet pod
  names and `delete` is granted only in fence mode (`list` stays unscoped), so a
  leaked ServiceAccount token cannot manipulate arbitrary namespace pods (#154).
- The pgbackrest Role's `pods`/`pods/exec` are scoped to the StatefulSet pod
  names instead of namespace-wide (#134).
- `global.annotations` render under `metadata.annotations`, not `labels`, so
  non-label-safe values no longer break apply and reach annotation consumers
  (#128).

### Fail-fast validation

- `postgresql.existingSecret.enabled=true` with an empty name fails at render
  instead of producing an empty `secretKeyRef.name` (#137).
- `pgbackrest.enabled` with `repmgr.enabled=false` fails at render: the
  pgbackrest binary and `archive_command` run in the postgresql container, which
  is the plain postgres image in standalone mode (#142).

## Migrating from 0.5.87

`helm upgrade my-release cagriekin/pg` with image
`cagriekin/repmgr:trixie-5.5.0-15` is the migration; PostgreSQL pods roll once
for the new image tag, the new `startupProbe`, and the RBAC scoping. Note that
the new fail-fast guards (#133, #137, #142) reject previously-accepted but
broken configurations at render time — if an upgrade now fails to template,
the error message names the offending value.

## 0.5.87

### Fixed

- repmgr image bumped to `trixie-5.5.0-10`: the primary node is now
  registered with a retry loop (matching the standby path) and the
  role probe retries until definitive. Previously `repmgrd-entrypoint`
  ran a single `repmgr primary register` under `set -e`; on a slow or
  contended host that register could race the postgresql container's
  init SQL (`CREATE EXTENSION repmgr`, repmgr user) and fail,
  crash-looping repmgrd into a backoff that outlived the install wait
  and failed the deploy. No chart behavior change beyond the image tag.

## Migrating from 0.5.86

`helm upgrade my-release cagriekin/pg` with image
`cagriekin/repmgr:trixie-5.5.0-10` is the migration; PostgreSQL pods
roll once for the new image tag.

## 0.5.86

### Fixed

- A full-cluster restart after a failover no longer rolls the database
  back to the failover point and destroys the surviving newer data
  (#125). Under the default `OrderedReady`, the lowest-ordinal pod is
  recreated first and alone, so the stale ex-primary (older timeline)
  came up read-write and the real primary (newer timeline) then
  re-cloned from it. Three layers fix it:
  1. The repmgr image (tag `trixie-5.5.0-9`) no longer re-clones a
     primary-state data directory by ordinal in `init-repmgr.sh`; it
     defers to the entrypoint guard, which only ever rewinds FORWARD to
     a newer-timeline peer. This stops the backward clone that destroyed
     data and makes role follow data state, not pod ordinal.
  2. A node whose timeline is at least as high as every reachable
     primary stays a primary instead of cloning down to a stale one.
  3. The service-updater records the highest-timeline primary in a
     durable, runtime-owned ConfigMap (`<fullname>-primary`) and refuses
     to route writes to a lone primary below that highwater -- so the
     stale pod that boots first under OrderedReady is never selected,
     while a legitimate new failover (always a higher timeline) is not
     blocked. The marker is written via kubectl at runtime, not as a
     helm template, so `helm upgrade` / ArgoCD sync cannot reset it.

## Migrating from 0.5.85

`helm upgrade my-release cagriekin/pg` plus the new image tag
`cagriekin/repmgr:trixie-5.5.0-9` is the migration; PostgreSQL pods roll
once (new image, new `PRIMARY_MARKER` env). The repmgr Role gains
`configmaps` get/create/patch for the marker. Running repmgr on
`postgresql.persistence.enabled=false` remains unsupported for the
full-restart case (the data dir must survive). If the recorded
highest-timeline primary is ever permanently lost, the service-updater
logs the exact `kubectl delete configmap <fullname>-primary` command to
accept its data loss and resume.

## 0.5.85

### Fixed

- The service-updater no longer repoints the write Service to a
  resurrected stale primary (#124). `get_current_master` trusted each
  node's self-reported `repmgr.nodes` metadata and returned the first
  responder in ordinal order, so a stale ex-primary still claiming
  `type=primary` in its own metadata would win and the selector would
  flip to it (with the readonly Service then serving the other
  timeline) -- silent data divergence. Master determination now
  classifies nodes by actual role (`pg_is_in_recovery()`), and the
  selector moves only when exactly one live primary exists; two or more
  is treated as a split-brain and never used to repoint.
- Split-brain fence now selects the survivor by timeline then numeric
  LSN, not a lexicographic string compare (#131). `pg_current_wal_lsn()`
  returns unpadded hex, so `[[ a > b ]]` mis-ordered LSNs across
  digit-width boundaries (`9/..` vs `10/..`) and could keep the behind
  node while wiping the ahead one. Timeline now dominates the choice (a
  stale primary can hold a higher LSN on the old timeline than the
  promoted primary on the new one), LSN segments are compared with
  `16#` arithmetic, and every stale primary is fenced and deleted (not
  just the last one seen) so 3+ way split-brains fully resolve; each
  deleted pod rejoins as a standby via the image's pg_rewind guard.

## Migrating from 0.5.84

`helm upgrade my-release cagriekin/pg` is the entire migration. No
pods roll: the service-updater ConfigMap is not checksummed into the
StatefulSet pod template, so running sidecars pick up the new logic on
their next restart (or restart the StatefulSet to apply immediately).
The fixes are behavioral and only change what happens during a
stale-primary resurrection or a split-brain.

## 0.5.84

### Changed

- The stale-primary protection for issue #123 moved from a chart-side
  bash wrapper into the repmgr image entrypoint (image tag
  `trixie-5.5.0-8`), so it runs on every container start, including
  container-only restarts (CrashLoopBackOff, OOM, liveness kill) that
  never re-run the init container -- the exact gap that let a crashed
  primary resume read-write on a stale timeline after a standby was
  promoted. Detection now reads the peer's timeline from
  `pg_walfile_name(pg_current_wal_lsn())` (which reflects a fast
  promotion immediately, unlike `pg_control_checkpoint()` which lags by
  minutes under load), settles only while no peer is reachable so a
  healthy primary restart adds no latency, and fails closed when the
  local timeline is unreadable while a peer is primary. Repair is an
  in-place `repmgr node rejoin --force-rewind` (pg_rewind works because
  PostgreSQL 18 initdb enables data checksums by default), falling back
  to a full re-clone only if rewind fails; a node whose data is empty
  while the cluster already has a primary refuses to initialize a
  divergent database. The chart now invokes the image entrypoint
  directly, passes `REPMGR_NODE_COUNT` so the peer scan matches the
  cluster size, and the obsolete `repmgr.stalePrimary.action` value
  was removed.

## Migrating from 0.5.83

`helm upgrade my-release cagriekin/pg` is the entire migration; the
StatefulSet pod template changes (new image tag, clean entrypoint
command), so PostgreSQL pods roll once. Running repmgr on
`postgresql.persistence.enabled=false` (emptyDir) is not recommended:
a container restart still rejoins correctly, but a pod recreation loses
the data dir, and if a standby was promoted in the meantime the node
refuses to initialize rather than fork a divergent cluster -- use
persistent volumes so pg_rewind/clone can repair it.

## 0.5.83

### Fixed

- A crashed primary no longer resurrects as a stale read-write primary
  when only its container restarts (#123). Re-clone logic lives in the
  repmgr-init initContainer, which does not re-run on container-only
  restarts (CrashLoopBackOff, OOM kills), so after a standby promotion
  the old primary would come back read-write on the stale timeline —
  a split-brain under default values. The postgresql container start
  is now wrapped by a guard: before starting read-write with existing
  data, it scans peers for an active primary on a NEWER timeline
  (promotion always bumps the timeline, so newer-elsewhere is proof of
  staleness) and refuses to start. `repmgr.stalePrimary.action`
  controls recovery: `reclone` (default) deletes the own pod so the
  existing repmgr-init re-clone and repmgrd re-register pipeline
  repairs the node; `halt` crash-loops with the data directory left
  untouched for inspection. pg_rewind-based repair is not possible on
  these clusters (initdb runs without data checksums or
  wal_log_hints), so re-clone via pod recreation is the repair path.
  The guard also refuses to initialize a fresh database when the data
  directory is empty but a peer is already an active primary
  (reachable on ordinal 0 without persistent storage, whose init path
  assumes first-boot), which previously bootstrapped a brand-new
  divergent primary next to the live cluster. Automatic re-clone of
  ordinal 0 therefore requires persistent storage; without it the pod
  halts with a clear error instead of silently splitting the cluster.

## Migrating from 0.5.82

`helm upgrade my-release cagriekin/pg` is the entire migration.
The StatefulSet pod template changes (wrapped container command), so
PostgreSQL pods roll once. Behavior changes only in the stale-primary
scenario, which previously produced a silent split-brain.

## 0.5.82

### Fixed

- The prometheus exporter `/metrics` endpoint returned HTTP 500 on
  every scrape in the unpublished 0.5.73-0.5.81 versions: the #22
  custom query group was named `pg_replication`, colliding with the
  built-in replication collector's `pg_replication_lag_seconds`
  (the Prometheus registry rejects two metrics with the same name
  and different help text, failing the whole scrape). The group is
  now `pg_wal_replication` and no longer duplicates the built-in
  lag metric; the 0.5.73 notes were corrected in place.

## Migrating from 0.5.81

`helm upgrade my-release cagriekin/pg` is the entire migration.
With the exporter enabled the configmap change rolls only the
exporter Deployment; database pods do not roll.

## 0.5.81

### Added

- PGPool troubleshooting guide at the end of the README (mirrored in
  pgvector): isolating connectivity failures between PGPool-II and the
  backends, checking backend status via `SHOW pool_nodes` and the pcp
  commands authenticated from the pgpool admin Secret, post-failover
  recovery including the `PrimaryChanged` Kubernetes Events emitted by
  the service-updater, readonly Service endpoint checks, and log
  locations with common messages (#25).

## Migrating from 0.5.80

Documentation only; no rendered resources change and no pods roll.

## 0.5.80

### Added

- Multi-Zone Deployment section in the README (#24): the built-in
  hostname and zone anti-affinity defaults, enforcing a hard zone
  requirement via `postgresql.affinity` (which replaces the built-in
  rules wholesale), spreading PGPool-II with
  `pgpool.topologySpreadConstraints`, `WaitForFirstConsumer` storage
  classes and the zonal volume pinning trade-off, and routing reads
  across zones through the `<fullname>-readonly` Service.

## Migrating from 0.5.79

Documentation only; no rendered resources change and no pods roll.

## 0.5.79

### Added

- The service-updater sidecar now records a core/v1 Kubernetes Event
  (reason `PrimaryChanged`, type Normal) on the primary Service every
  time it actually changes the selector to a new primary (#23), with
  the old and new pod names in the message, so failover history is
  visible via `kubectl describe service` and `kubectl get events`.
  The Event is created strictly after a successful selector patch and
  is best-effort: creation failures are logged as warnings and never
  fail or delay failover. The repmgr Role additionally grants
  `create` on core `events`.

## Migrating from 0.5.78

`helm upgrade my-release` is the entire migration. No pods roll with default values: the service-updater ConfigMap is not checksummed into the StatefulSet pod template and the Role is patched in place. Running sidecars keep executing the already-loaded script, so PrimaryChanged events start appearing after each pod's next restart. No new values.

## 0.5.78

### Added

- Read-only replica Service `<fullname>-readonly` for routing read traffic to standbys (#17), rendered whenever repmgr is enabled. Service selectors are equality-only and cannot express "not the primary", so the service selects a new `pg-role: standby` pod label that the service-updater sidecar now converges on every postgresql pod each reconciliation tick (the resolved primary gets `pg-role: primary`, everything else `standby`; pods recreated or added by scale-up are picked up on the next tick). Pods without the label are never selected, so the primary can never leak into the readonly endpoints. The repmgr Role's pods rule gains `get`/`list`/`patch` alongside the existing `delete`.

## Migrating from 0.5.77

`helm upgrade my-release cagriekin/pg` is the entire migration; no pods roll with default values (the StatefulSet pod template is unchanged and the service-updater configmap is not checksummed into it). Because the running service-updater process does not re-read its script, pg-role labeling -- and therefore readonly endpoints -- only activates once the service-updater containers restart (next pod roll or container restart); until then, and with `postgresql.replicaCount: 0` permanently, the `<fullname>-readonly` Service exists but has no endpoints, which is the safe default (unlabeled pods are never selected, so reads can never hit the primary by accident). The RBAC change applies immediately.

## 0.5.77

### Changed

- PGPool admin (PCP) credentials moved out of the pgpool ConfigMap and
  into a Secret (#15). `pgpool.admin.username` / `pgpool.admin.password`
  (defaults `admin`/`admin`) render into a chart-managed Secret, or
  bring your own via
  `pgpool.admin.existingSecret.{enabled,name,usernameKey,passwordKey}`.
  The init container now generates `pcp.conf` from the Secret at pod
  startup, so the plaintext password no longer lands in a ConfigMap.
  The old `pgpool.adminUsername` / `pgpool.adminPassword` values were
  removed and fail rendering when still set, instead of being silently
  ignored.

## Migrating from 0.5.76

With default values (pgpool.enabled=false) nothing changes and no pods roll. With PGPool enabled, the pgpool Deployment rolls once on upgrade (pcp.conf left the ConfigMap, so the config checksum changes); PostgreSQL pods do not roll. pgpool.adminUsername/pgpool.adminPassword were renamed: anyone setting them must move to pgpool.admin.username/pgpool.admin.password or pgpool.admin.existingSecret — rendering fails fast with a pointer to the new keys until they do. PCP credentials themselves are unchanged for default installs (admin/admin, now stored in a Secret).

## 0.5.76

### Changed

- Extension paths are no longer hardcoded to PostgreSQL 18 (#18). The
  copy-base-ext/copy-ext init-container `cp` commands and the
  ext-lib/ext-share volumeMounts now derive
  `/usr/lib/postgresql/<major>/lib` and
  `/usr/share/postgresql/<major>/extension` from the new
  `postgresql.majorVersion` value (default `"18"`), validated via
  `required` when `postgresql.extensions.enabled=true`. Keep it in
  sync with `postgresql.image.tag` when running a different major.

## Migrating from 0.5.75

`helm upgrade my-release cagriekin/pg` is the entire migration. With default values nothing rolls: `postgresql.majorVersion` defaults to "18", so every rendered manifest is byte-identical to the previous release (the affected paths only render when `postgresql.extensions.enabled=true`, and even then they resolve to the same /18/ paths). Users running a non-18 image with extensions enabled should set `postgresql.majorVersion` to match their image's major version; leaving it empty now fails the render with a clear error.

## 0.5.75

### Added

- `repmgr.monitoringHistoryDays` (default `7`) bounds the
  `repmgr.monitoring_history` table (#19). repmgrd runs with
  `monitoring_history=true` but repmgr 5.x has no conf-based retention
  (the image's `monitoring_history_keep` line is silently ignored as an
  unknown parameter), so the table grew forever. The repmgrd sidecar now
  spawns a resilient background loop that once per day, on the primary
  only, runs `repmgr cluster cleanup --keep-history=<days>`; cleanup
  failures log a warning and never take down repmgrd.

## Migrating from 0.5.74

`helm upgrade my-release cagriekin/pg` is the entire migration. With repmgr enabled (the default) the StatefulSet pod template changes (new env var and startup script in the repmgrd sidecar), so the postgresql pods roll once via the normal rolling update; repmgr handles the failover as on any upgrade. The first prune of an existing oversized monitoring_history table happens within 24h of the new pods starting. With repmgr disabled nothing changes and no pods roll.

## 0.5.74

### Added

- Zone-aware pod anti-affinity on the postgresql StatefulSet (#16). The
  default affinity block now includes a preferred (soft) podAntiAffinity
  term on `topology.kubernetes.io/zone` (weight 100) alongside the
  existing required hostname term, so pods spread across availability
  zones when possible while hostname spreading stays mandatory.
  Single-zone clusters are unaffected (the zone rule is best-effort),
  and a user-supplied `postgresql.affinity` still replaces the default
  block wholesale.

## Migrating from 0.5.73

With default values the StatefulSet pod template changes (a new preferred zone anti-affinity term), so postgresql pods roll once on upgrade following the chart's update strategy. The new rule is preferred (soft): scheduling behavior only changes on multi-zone clusters where the scheduler will now favor spreading pods across zones; single-zone clusters schedule exactly as before. Releases that set postgresql.affinity are unaffected — their custom affinity still replaces the default block entirely. No values changes or manual action required.

## 0.5.73

### Added

- Replication recovery-state and WAL-apply metrics in the prometheus
  exporter (#22): a `pg_wal_replication` custom query group exposes
  `pg_wal_replication_in_recovery` (`pg_is_in_recovery()` as a gauge
  — summing `in_recovery == 0` across the release's instances detects
  split-brain) and `pg_wal_replication_receive_replay_lag_bytes`
  (receive/replay LSN diff, `0` on the primary), alongside the
  exporter's built-in `pg_replication_lag_seconds` and
  `pg_replication_is_replica`. The queries run on every instance via
  the exporter's multi-DSN `/metrics` and the per-pod `/probe`
  ServiceMonitor targets, so standby lag is directly visible. The
  custom group deliberately avoids the `pg_replication` namespace:
  registering a metric name the built-in replication collector
  already serves makes the registry reject every scrape with HTTP
  500.

## Migrating from 0.5.72

`helm upgrade my-release cagriekin/pg` is the entire migration. With the default `prometheusExporter.enabled=false` nothing is rendered and no pods roll. With the exporter enabled, the configmap change rolls only the exporter Deployment (via its checksum/config annotation); database pods do not roll and no values changes are required — the new metrics appear on the next scrape.

## 0.5.72

### Fixed

- The backup script now verifies at least one backup newer than
  `RETENTION_DAYS` exists under the S3 prefix before running retention
  cleanup (#21). Previously `mc find --older-than --exec rm` ran
  unconditionally, so if uploads had been broken (or landing under a
  different prefix) for longer than `backup.retentionDays`, cleanup
  deleted every remaining backup. When no recent backup is visible the
  job now exits 1 without deleting anything. In the normal flow the
  just-uploaded dump satisfies the check, so the guard only fires when
  something is genuinely wrong.

## Migrating from 0.5.71

`helm upgrade my-release cagriekin/pg` is the entire migration. No pods roll with default values; with `backup.enabled=true` only the backup ConfigMap changes, which the next CronJob run picks up. No values changes are required. The backup job now fails (exit 1) instead of deleting when no backup newer than retentionDays is visible under the configured prefix — a condition that previously resulted in silent total deletion.

## 0.5.71

### Changed

- Default `postgresql.livenessProbe.failureThreshold` raised from 6
  to 10 (#20). With the default `periodSeconds: 10` the kubelet now
  waits 100s of failed `pg_isready` checks before restarting
  PostgreSQL instead of 60s, so sustained heavy load no longer
  triggers false liveness restarts. The readiness probe defaults are
  unchanged.

## Migrating from 0.5.70

With default values the StatefulSet pod template changes (livenessProbe.failureThreshold 6 -> 10), so PostgreSQL pods WILL roll once on upgrade. No action is required; releases that already override postgresql.livenessProbe.failureThreshold in their own values are unaffected and do not roll because of this change.

## 0.5.70

### Added

- Complete Chart.yaml metadata (#114): `home`, `icon`, `sources`,
  `keywords` and `maintainers`, shown by Artifact Hub and
  `helm show chart`.

## Migrating from 0.5.69

`helm upgrade my-release cagriekin/pg` is the entire migration.
Metadata only; no rendered resources change and no pods roll.

## 0.5.69

### Fixed

- NetworkPolicy egress no longer hardcodes port 443 as the only
  external port (#113). The postgresql policy now also allows 6443
  (API servers on kubeadm-style clusters, used by the service-updater
  sidecar and lifecycle-hook kubectl) and, when pgBackRest is enabled,
  the port derived from `pgbackrest.s3.endpoint` (explicit port wins;
  otherwise `http://` maps to 80 and anything else to 443). Previously
  WAL archiving to S3 endpoints on non-443 ports (e.g. MinIO `:9000`)
  and kubectl against 6443 API servers were silently dropped.

### Added

- `networkPolicy.postgresql.extraEgress` and
  `networkPolicy.pgpool.extraEgress` (both default `[]`) for
  additional egress rules, mirroring the existing `extraIngress`.

## Migrating from 0.5.68

`helm upgrade my-release cagriekin/pg` is the entire migration. No
pods roll. With `networkPolicy.enabled=false` (the default) nothing
changes; with it enabled the postgresql policy additionally allows
egress to 6443 and the pgBackRest S3 endpoint port.

## 0.5.68

### Added

- Per-component `priorityClassName` support (#112):
  `postgresql.priorityClassName`, `pgpool.priorityClassName`,
  `prometheusExporter.priorityClassName`, `backup.priorityClassName`
  and `pgbackrest.cronjob.priorityClassName` (all default `""`), so
  the database StatefulSet can be scheduled at higher priority than
  stateless workloads and survive node-pressure evictions.

## Migrating from 0.5.67

`helm upgrade my-release cagriekin/pg` is the entire migration. With
the default empty values nothing is rendered and no pods roll.

## 0.5.67

### Added

- `imagePullSecrets` (top-level value, default `[]`) now propagates to
  every pod template (#111): the PostgreSQL StatefulSet, the pgpool
  and prometheus exporter Deployments, and the backup and pgBackRest
  CronJobs. Previously no pod template carried pull secrets, so none
  of the chart's images could come from a private registry.

## Migrating from 0.5.66

`helm upgrade my-release cagriekin/pg` is the entire migration. With
the default `imagePullSecrets: []` nothing is rendered and no pods
roll.

## 0.5.66

### Fixed

- Credentials containing special characters no longer corrupt pgpool
  and exporter configuration (#108). Placeholder substitution in the
  pgpool and exporter init containers used
  `sed -i "s/__X__/$VALUE/g"`, which corrupts or fails on `/`, `&`
  and `\`; both now use a byte-safe awk splice with values passed via
  the environment, plus context-appropriate escaping: backslash
  escaping for pgpool.conf strings (`\\`, `\'`) and pool_passwd
  fields (`\\`, `\:`), YAML quote doubling for postgres_exporter.yml.
  The pgpool check passwords moved out of pgpool.conf entirely: blank
  values make pgpool read pool_passwd, whose entry is now
  `TEXT`-prefixed -- unprefixed entries are taken as md5 hashes,
  which happened to work against md5 backends (repmgr image) but
  cannot answer the scram challenges of standalone official-image
  backends. The exporter `DATA_SOURCE_NAME` env built its URI from
  raw `$(VAR)` expansion, which `@`, `:`, `/`, `?`, `#` or `%` in
  credentials break; the init container now assembles the DSN with
  every credential byte percent-encoded and the exporter reads it
  from a file. Chart-generated passwords are alphanumeric and were
  unaffected; `existingSecret` passwords are arbitrary and hit all of
  these paths.
- pgpool probes now run a query through pgpool instead of a TCP
  connect (#122). A pgpool that rejects every session with "all
  backend nodes are down" still accepts TCP, so the old probes kept
  it Ready and never restarted it -- a permanent wedge reachable on
  any standalone install whose backend is unready for ~30s at
  startup (the repmgr flavor was masked by the service-updater
  restarting pgpool). A failing liveness now restarts pgpool, which
  rediscovers backends with a fresh status file.
- The pgpool pod template now carries a checksum of the pgpool
  configmap: pgpool.conf and pool_passwd are rendered into an
  emptyDir by the init container, so configmap changes previously
  never reached running pods.

## Migrating from 0.5.65

`helm upgrade my-release cagriekin/pg` is the entire migration. The
pgpool and exporter pod templates change, so those deployments roll
once; the PostgreSQL StatefulSet is untouched.

## 0.5.65

### Fixed

- Disabling `postgresql.configuration` and `pgbackrest` after they had
  been enabled bricked the cluster on the next pod restart (#107): the
  `include_dir = '/etc/postgresql/conf.d'` line appended to
  `postgresql.conf` persists in PGDATA, but the conf.d configmap mount
  is removed, and PostgreSQL refuses to start on a missing include_dir
  directory. The setup-config init container now always runs: it
  appends the line when either feature is enabled and strips a stale
  line when both are disabled.

## Migrating from 0.5.64

`helm upgrade my-release cagriekin/pg` is the entire migration. The
StatefulSet pod template changes, so pods roll once. If a cluster is
already crash-looping from this defect, upgrading to this version
repairs it: the init container strips the stale line before PostgreSQL
starts.

## 0.5.64

### Fixed

- The postgresql preStop hook no longer attempts to promote a standby;
  it now only stops PostgreSQL cleanly and leaves promotion to repmgrd
  (#102). The old hook's remote `pg_promote()` never actually ran (the
  image ships no `.pgpass` and pg_hba requires scram/md5 cross-pod, so
  the unauthenticated call failed silently behind `2>/dev/null`), and
  its verification loop polled local `pg_is_in_recovery()` -- always
  `f` on the old primary -- burning the full 30s on every primary
  shutdown. Repairing the call as #102 originally suggested proved
  worse than removing it: a raw `pg_promote()` bypasses repmgr.nodes
  metadata, the promoted node keeps `type='standby'`, and every
  repmgrd crash-loops on the stale metadata (reproduced in the upgrade
  test). repmgrd's own `promote_command` (`repmgr standby promote`)
  updates the metadata correctly and is the only promotion path the
  cluster has ever actually converged through.

## Migrating from 0.5.63

`helm upgrade my-release cagriekin/pg` is the entire migration. The
StatefulSet pod template changes, so pods roll once. Primary shutdown
during the roll is now ~30s faster (no dead verification loop);
failover behavior is unchanged because the removed promotion never
executed.

## 0.5.63

### Fixed

- postStart primary discovery scanned `seq 0 (replicaCount - 1)` while
  the StatefulSet runs `replicaCount + 1` pods, so
  `lifecycle.postStart.additionalCommands` was silently skipped
  whenever the primary was the last ordinal after a failover (#103).
  The loop now scans ordinals `0..replicaCount`, matching the
  service-updater.
- repmgrd pre-register role detection used
  `psql -h 127.0.0.1 -U postgres -d postgres`, which only worked
  because the image's initdb happens to create a `postgres` superuser
  and trust 127.0.0.1; it now uses the repmgr credentials already in
  the container env (#104).
- The repmgrd pre-register peer scan iterated a hardcoded `seq 0 9`,
  breaking primary discovery for clusters with more than 10 pods; the
  bound now derives from `replicaCount`. The type-backfill node id is
  read from the generated `/etc/repmgr/repmgr.conf` instead of
  re-deriving the image's `ordinal + 1000` convention, and the
  backfill is skipped with an explicit error if `node_id` cannot be
  parsed (#105).

## Migrating from 0.5.62

`helm upgrade my-release cagriekin/pg` is the entire migration. The
StatefulSet pod template changes, so pods roll once.

## 0.5.62

### Fixed

- `helm upgrade` no longer repoints the primary Service selector back
  to pod-0 (#109). The rendered Service now preserves the live
  `statefulset.kubernetes.io/pod-name` selector via `lookup`, mirroring
  the secret reuse pattern, falling back to pod-0 only at bootstrap.
  Previously every upgrade after a failover routed writes at a
  read-only standby until the service-updater's next tick (up to 30s)
  -- and with helm v4 (server-side apply) the upgrade failed outright
  with a field-manager conflict on `.spec.selector`, because the
  service-updater's `kubectl patch` owns the field once a failover has
  occurred. Rendering pipelines that never talk to the cluster
  (`helm template`, ArgoCD) still emit the pod-0 bootstrap selector;
  the service-updater re-asserts the correct primary on its next tick.

## Migrating from 0.5.61

`helm upgrade my-release cagriekin/pg` is the entire migration. If a
previous helm v4 upgrade already failed with
`conflict with "kubectl-patch" using v1: .spec.selector`, this version
resolves it: the rendered selector now matches the live value, so the
apply no longer conflicts.

## 0.5.61

### Fixed

- Rendering now fails fast when `repmgr.enabled=false` is combined with
  `postgresql.replicaCount > 0` (#106). The StatefulSet always runs
  `replicaCount + 1` pods; without repmgr those extra pods were
  independent PostgreSQL instances with their own PVCs and no
  replication, while the PGPool config labeled them `replica1..N` under
  `streaming_replication` clustering -- reads silently hit empty or
  diverged databases. Standalone mode requires
  `postgresql.replicaCount=0`.

## Migrating from 0.5.60

`helm upgrade my-release cagriekin/pg` is the entire migration for
repmgr deployments and single-instance standalone deployments. If your
values set `repmgr.enabled=false` with `postgresql.replicaCount > 0`,
the upgrade is rejected at template time: those extra pods were never
replicas, and any data written to them through PGPool load balancing
exists only on that pod. Recover that data before switching to
`repmgr.enabled=true` (which re-clones standbys from the primary) or
`postgresql.replicaCount=0` (which orphans the extra PVCs).

## 0.5.60

### Fixed

- Backup against TLS S3 endpoints (real AWS S3) failed with
  `x509: certificate signed by unknown authority`: the postgres image
  ships no CA bundle (`/etc/ssl/certs/ca-certificates.crt` absent in
  `postgres:18.1-trixie`). The 0.5.59 kind test used plain-HTTP MinIO,
  so the gap only surfaced in production. The mc-installer init
  container now also copies the mc image's CA bundle into the shared
  volume and the backup script exports `SSL_CERT_FILE` pointing at it.

## Migrating from 0.5.59

`helm upgrade my-release cagriekin/pg` is the entire migration. No PVC
recreate, no StatefulSet recreate, no password rotation, no forced
failover.

## 0.5.59

### Fixed

- Backup CronJob pods never started: the pod spec set `runAsNonRoot: true`
  without `runAsUser`, and both the postgres and minio/mc images default
  to root, so the kubelet rejected container creation with
  `CreateContainerConfigError` until the job hit `activeDeadlineSeconds`
  (`DeadlineExceeded`, no logs, no events by morning). Backup pod and
  container security contexts are now configurable via
  `backup.podSecurityContext` and `backup.containerSecurityContext`,
  defaulting to `runAsUser: 999` / `runAsGroup: 999` (the postgres uid in
  the official image).
- Wired `test-backup-restore` into the `test-cluster` Make target so the
  backup path is exercised by the standard test run.
- Generated secret rotated `password` and `repmgr-password` on every
  `helm upgrade` (`randAlphaNum` with no reuse), so any upgrade that
  added a standby deadlocked: the new pod mounted fresh credentials the
  running cluster did not have and `repmgr-init` looped on
  `password authentication failed` until the rollout timed out
  (`test-upgrade` failure, Ready 2/3). The secret template now reuses
  values from the live secret via `lookup` and only generates passwords
  that do not exist yet. Note: `lookup` returns nothing under
  `helm template`/`--dry-run`, so rendering pipelines that never talk to
  the cluster (e.g. ArgoCD) should keep using
  `postgresql.existingSecret`.

## Migrating from 0.5.58

`helm upgrade my-release cagriekin/pg` is the entire migration. No PVC
recreate, no StatefulSet recreate, no password rotation, no forced
failover.

## 0.5.58

### Fixed

- 0.5.57 dropped the image entrypoint's `Waiting for local PostgreSQL`
  and `primary register --force` steps along with the broken standby
  verify, so primary pods crashed at boot. Restore both in the chart
  wrapper: wait for local PG via `pg_isready`, then branch on
  `pg_is_in_recovery()` — `f` runs `primary register --force`, `t`
  runs the existing standby pre-register block. Standby gate changed
  from `ORDINAL != 0` to `IN_RECOVERY = t` so a failed-over pod-0
  rejoining as standby also takes the standby path.

## Migrating from 0.5.57

`helm upgrade my-release cagriekin/pg` is the entire migration. No PVC
recreate, no StatefulSet recreate, no password rotation, no forced
failover.

## 0.5.57

### Fixed

- Bypass the repmgr image's `repmgrd-entrypoint.sh` and exec `repmgrd`
  directly from the StatefulSet's repmgrd container command. The image
  entrypoint re-runs `standby register --force` (which on PG18 +
  repmgr 5.5.0-7 lands `type=''` again) and then verifies via
  `psql -h <primary> -U repmgr -d repmgr` without `PGPASSWORD`. Internal
  cluster traffic hits `scram-sha-256` in pg_hba, the verify query
  comes back empty, and the loop exits 1 with
  `Primary does not show node N as standby (current type: )`. The
  pre-register block in this chart already registers the standby and
  backfills `type='standby'`, so the image's register+verify is
  redundant.

## Migrating from 0.5.56

`helm upgrade my-release cagriekin/pg` is the entire migration. No PVC
recreate, no StatefulSet recreate, no password rotation, no forced
failover. Standby pods that were CrashLooping on repmgrd converge on
their next restart; unaffected clusters see no behaviour change.

## 0.5.56

### Fixed

- Defensive `UPDATE repmgr.nodes SET type='standby' WHERE node_id=<local>
  AND (type IS NULL OR type='')` after pre-register on the primary.
  Some PG18 + repmgr image combos report `standby registration complete`
  but leave the row's `type` empty, breaking the image's verify-loop
  with `Primary does not show node N as standby (current type: )`.
  WHERE clause makes the UPDATE a no-op on already-correctly-typed
  rows.
- Test: new `pg/tests/test-repmgr-chaos.sh` deletes the standby pod
  3 times and re-asserts `type='standby'` after each replacement —
  the post-restart re-occurrence shape that manual SQL fixes cannot
  cover. Wired into `Makefile` and CI.

## Migrating from 0.5.55

`helm upgrade my-release cagriekin/pg` is the entire migration. No PVC
recreate, no StatefulSet recreate, no password rotation, no forced
failover. Affected clusters converge `type='standby'` on the next
standby restart; unaffected clusters see no behaviour change.

## 0.5.55

### Fixed

- `fix_user_auth` postStart hook (0.5.54) used
  `psql -c "DO $$ ... :'u' ... $$;"`. `psql -c` does **not** perform
  `:'var'` substitution — per docs, the command must contain "no
  psql-specific features". The server received `:'u'` literally and
  rejected every call with `ERROR: syntax error at or near ":"`; the
  MD5→SCRAM rehash silently never ran. Connectivity kept working because
  the md5-fallback line in `pg_hba.conf` accepted the legacy hashes,
  masking the failure on noisy clusters.
  Fix: build the SQL into a bash variable and feed it to psql via
  here-string (`<<<`), which goes through the MainLoop reader where
  `:'var'` IS substituted. Values flow through per-session GUCs
  (`myvars.tgt_user` / `myvars.tgt_pass` — `user` would clash with the
  reserved keyword) read back inside the DO block via `current_setting()`.
  PG<14 skip, `format('%I/%L')` quoting, idempotent `rolpassword LIKE
  'md5%'` gate preserved. Failure now logs a loud line to pod stdout
  instead of being swallowed by `>/dev/null`.
- Standby `repmgr.nodes` row landed with `type=''` on the primary because
  `cagriekin/repmgr:trixie-5.5.0-7`'s entrypoint runs `repmgr standby
  register --force` without `--upstream-node-id`, crashing the standby
  with `Primary does not show node N as standby`. The chart's `repmgrd`
  container now pre-registers with an explicit upstream node_id and
  delegates to the image entrypoint. Workaround until the image ships
  the fix.

## Migrating from 0.5.54

`helm upgrade my-release cagriekin/pg` is the entire migration: no PVC
recreate, no StatefulSet recreate, no password rotation, no forced
failover, no new required `values.yaml` field, PG13 still skipped. The
MD5→SCRAM rehash completes on the first 0.5.55 pod start (idempotent on
re-run).
