# Changelog

## 1.5.3 - 2026-11-07

### Changed

- **Every `resources` block is validated by `values.schema.json` (#271).** The 4 blocks the
  templates read are declared through one shared definition: `requests`/`limits` only (a typo'd
  `reqests:` is rejected instead of rendering a silently resource-less container), a scalar fails
  the render naming the path instead of reaching the API server, and quantities stay string or
  number with the key set open, so `cpu: 1`, `cpu: "100m"`, `memory: 1Gi` and extended resources
  (`nvidia.com/gpu`, `hugepages-2Mi`) all render as before. No default or template changed.

## 1.5.2 - 2026-08-03

Bugfix: the standalone exporter Deployment can now carry pod annotations (additive; default
`{}` renders no new manifest fields, so existing installs are unchanged).

### Fixed
- **`architecture: standalone` had no way to annotate the exporter pod.** The exporter runs
  as its own Deployment there, and the template passed no `podAnnotations` to
  `common.exporterDeployment` — `redis.podAnnotations` only reaches the StatefulSet. Agents
  that discover targets from pod annotations (Grafana Alloy, Prometheus
  `kubernetes_sd_configs` with a `prometheus.io/scrape` keep rule) therefore never scraped a
  standalone install's exporter, and `exporter.serviceMonitor.enabled` is no help without a
  Prometheus Operator. `redis_up` was absent entirely, which surfaces as "no data" rather
  than as a down signal.

### Added
- `exporter.podAnnotations` (default `{}`) — annotations for the standalone exporter
  Deployment's pod template. No-op in replication, where the exporter is a sidecar and
  `redis.podAnnotations` already applies.
- README "Annotation-based scrapers" section: when a ServiceMonitor is not enough, and the
  annotation snippet for each architecture.

## 1.5.0 - 2026-07-01

PVC lifecycle documentation and a retention knob (additive; `redis.persistence.retain`
defaults `true`, which renders no new manifest fields — existing installs are unchanged).

### Added
- `redis.persistence.retain` (default `true`) — controls the StatefulSet
  `persistentVolumeClaimRetentionPolicy`. `true` keeps data PVCs on uninstall and
  scale-down (no policy emitted; relies on the Kubernetes default `Retain`, so rendered
  output matches earlier versions). `false` emits
  `persistentVolumeClaimRetentionPolicy: {whenDeleted: Delete, whenScaled: Delete}` so
  PVCs are garbage-collected on uninstall and scale-down — for ephemeral/dev installs
  (requires Kubernetes 1.27+). Applies to both replication and standalone (#91).
- README "PVC lifecycle & reclaim behavior" section: PVC naming, why `helm uninstall`
  leaves PVCs behind, the `retain` knob, manual cleanup commands, the interaction with
  the PV/`storageClass` reclaim policy, and recovering data from orphaned PVCs (#91).

## 1.4.1 - 2026-07-01

Bugfix: standalone mode now honors pod scheduling fields (additive; no change to
replication mode or to standalone installs that don't set these).

### Fixed
- **`architecture: standalone` ignored `redis.nodeSelector`, `redis.tolerations`,
  `redis.affinity`, and `redis.podAnnotations`.** Only the replication StatefulSet
  rendered them, so a standalone install could not be pinned to a node pool — e.g. it
  could land on an EKS Auto Mode node that doesn't support the `ebs.csi.aws.com`
  (`gp3`) provisioner, leaving the PVC unbound and the pod Pending. The standalone
  StatefulSet now renders the same scheduling fields as the replication branch
  (no default podAntiAffinity, since standalone is a single pod).

## 1.4.0 - 2026-06-30

Grafana dashboard (additive; `exporter.dashboards.enabled` defaults `false`, so existing
installs render no new objects).

### Added
- `exporter.dashboards.*` — ship `dashboards/redis-dashboard.json` as a ConfigMap labeled for
  Grafana sidecar auto-discovery. Covers memory/fragmentation, hit/miss ratio, connected and
  blocked clients, command throughput and per-command latency, keyspace and evicted/expired
  keys, AOF/RDB persistence status, and replication health (#95).
- Configurable sidecar `label`/`labelValue`, ConfigMap `namespace`, `additionalLabels`, and
  `annotations` (e.g. `grafana_folder`). The dashboard's `datasource`/`namespace`/`service`/
  `pod` template variables make one dashboard serve both standalone and replication and
  any number of releases. The dashboard assumes the chart's ServiceMonitor (Prometheus
  Operator) scrape path for its `namespace`/`service`/`pod` target labels — the same labels
  the bundled alerts use (#95).

## 1.3.1 - 2026-06-29

Sizing guidance and a throughput baseline (docs + tests only; no chart template or values
changes, so rendered output is unchanged).

### Added
- `tests/test-performance.sh` + `values-performance.yaml` — opt-in `make test-performance`
  target that runs `redis-benchmark` against a small standalone instance and asserts a
  conservative throughput floor (regression guard, not a precise number) (#89).
- README "Sizing & performance" guide: memory headroom and `maxmemory` table, single-threaded
  CPU guidance, connection/`maxclients` notes, throughput expectations, and replication/
  persistence overhead (#89).

## 1.3.0 - 2026-06-24

Exporter configuration options (non-breaking; all new values default to the exporter's
own defaults, so existing installs are unchanged).

### Added
- `exporter.connectionTimeout` — Go-duration connection timeout passed as
  `REDIS_EXPORTER_CONNECTION_TIMEOUT` (#88).
- `exporter.logFormat` — `txt` (default logfmt) or `json`; passed as
  `REDIS_EXPORTER_LOG_FORMAT` (#88).
- Metric group toggles: `includeConfigMetrics`, `inclSystemMetrics`, `exportClientList`,
  `disableExporterMetrics` — map directly to the matching `REDIS_EXPORTER_*` boolean env
  vars; all default `false` (#88).
- `exporter.extraEnvVars` — arbitrary additional env vars for the exporter container
  (escape hatch for less-common flags, e.g. `REDIS_EXPORTER_SCRIPT`); supports both
  `value` and `valueFrom` forms (#88).
- All new options apply to both the replication per-pod sidecar and the standalone
  exporter Deployment via the shared `redis.exporterConfigEnv` helper (#88).

## 1.2.0

ACL support (non-breaking; `redis.auth.acl.enabled` defaults `false`, so existing installs
are unchanged).

### Added
- Redis ACL users via `redis.auth.acl` (#87): layer named, per-command/per-key users on top
  of password auth, in both `standalone` and `replication`. Passwords stay out of the
  ConfigMap (rendered into `redis.conf` at runtime from Secret-backed env).
- A chart-managed **operator user** (`redis.auth.acl.operatorUser`) — the privileged identity
  used for replication (`masteruser`/`masterauth`), Sentinel (`auth-user`/`auth-pass`), the
  exporter (`REDIS_USER`), and probes; lets you lock down the `default` user.
- Fail-fast validation of ACL config (auth prerequisite, username charset, no
  `on`/`off`/`nopass`/`reset*`/`>`/`#` and no shell metacharacters (`" $ ` + backslash) in
  `rules` — they are appended to `redis.conf` via a shell `echo` at startup —
  operator/`default` interlocks, ACL knobs set while `acl.enabled` is false, and BYO
  `existingSecret` requiring an explicit `passwordSecret.name` for every ACL user and the
  operator).

## 1.1.0

Operability and production-hardening (non-breaking; defaults unchanged).

### Added
- Fail-fast validation that `redis.config.maxmemory` does not exceed
  `redis.resources.limits.memory` (#82).
- `imagePullSecrets` applied to every pod — redis, sentinel, exporter, and the
  bootstrap init container (#84).
- Configurable production `redis.conf` settings: `loglevel`, `databases`,
  `slowlog-log-slower-than`, `slowlog-max-len`, `client-output-buffer-limit`, an
  explicit `dir /data`, and configurable `timeout` / `tcp-keepalive` (#81, #78).
- Complete `Chart.yaml` metadata: `home`, `icon`, `sources`, `maintainers` (#85).

## 1.0.0

High-availability replication via Redis Sentinel. **Breaking**: the default
`architecture` is now `replication`.

### Added
- `architecture: standalone | replication` toggle. `replication` runs a Redis master
  plus replicas with a Sentinel sidecar in every pod and automatic failover.
- Sentinel-aware client support: a `<fullname>-sentinel` Service on `:26379` for
  `SENTINEL get-master-addr-by-name`, and a headless Service for stable per-pod DNS.
- Failover-safe bootstrap (`redis-bootstrap` init container): discovers the live master
  from the Sentinels and joins as a replica, so a restarted ex-master never resurrects
  read-write. Config is rendered into an in-memory (`tmpfs`) volume so runtime rewrites
  never persist secrets to disk.
- Stable-DNS announcing (`replica-announce-ip`, `sentinel announce-ip` +
  `resolve-hostnames`/`announce-hostnames`) so pod-IP churn never strands the cluster.
- Write safety: `min-replicas-to-write` / `min-replicas-max-lag` (default 1 / 10).
- Secure-by-default: `redis.auth.enabled` and `networkPolicy.enabled` now default `true`.
  When no `existingSecret` is given the chart generates a random password Secret
  (persisted across upgrades via `lookup`).
- In-transit TLS (`tls.*`): TLS-only Redis + Sentinel + replication, optional mutual TLS
  (`tls.clientCertAuth`), exporter over TLS.
- Per-pod metrics: the exporter runs as a sidecar in replication so role/replication
  metrics exist per member; new HA alerts (master down, split-brain, replica/link down,
  writes-blocked tripwire).
- Scheduling knobs (`redis.affinity` default podAntiAffinity, `topologySpreadConstraints`,
  `nodeSelector`, `tolerations`, `priorityClassName`, `podAnnotations`) and
  `networkPolicy.extraEgress`. New `values-cloud.yaml` overlay.
- Live test suites: `test-replication.sh`, `test-failover.sh`, `test-tls.sh`.

### Changed
- **BREAKING**: default `architecture` is `replication` (3 pods + Sentinel). Pin
  `architecture: standalone` to keep the previous single-instance behavior.
- **BREAKING**: `auth.enabled` and `networkPolicy.enabled` default `true`.
- PodDisruptionBudget default shape is now `maxUnavailable: 1` +
  `unhealthyPodEvictionPolicy: AlwaysAllow` (was `minAvailable: 1`), and it is now enabled
  by default in every architecture (set `redis.podDisruptionBudget.enabled: false` to opt out).
- Re-vendored the `common` subchart (adds `unhealthyPodEvictionPolicy` support).

### Migration to 1.0.0
- To keep the old single Redis instance:
  `--set architecture=standalone --set redis.auth.enabled=false --set networkPolicy.enabled=false`.
- To adopt HA, plan for 3 pods on 3 nodes (default hard anti-affinity) and update clients
  to be Sentinel-aware (connect to `<release>-redis-sentinel:26379`).

### Known limitations
- Full-cluster cold boot seeds `pod-0` as master; if it was not the last master, writes
  not yet replicated to it can be lost. Steady-state failover is bounded by
  `min-replicas-to-write` and Sentinel selecting the most up-to-date replica. A durable
  last-master marker is tracked as a follow-up.
